export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#1c1c1e] text-white">
      {children}
    </div>
  )
}
