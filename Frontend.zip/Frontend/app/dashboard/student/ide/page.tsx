"use client"

import { useState, useEffect } from "react"
import { api } from "@/lib/api"
import { Loader2, Play, Trophy, AlertCircle, ChevronDown, ChevronUp, Lightbulb, BookOpen, CheckCircle2 } from "lucide-react"
import Editor from "@monaco-editor/react"
import Link from "next/link"

interface Problem {
  id: string
  title: string
  description: string
  difficulty: string
  concept: string
  testCases: Array<{ id: string; input: string; expectedOutput: string }>
}

interface ProblemInAssignment {
  id: string
  title: string
  difficulty: string
}

interface Assignment {
  id: string
  name?: string
  classroomId: string
  problemIds: string[]
  problems?: ProblemInAssignment[]
  mode: "guided" | "free"
  dueDate: string
  description?: string
}

interface SubmissionResult {
  success: boolean
  status: string
  metrics: {
    score: number
    runtime: string
    fileSize: number
    passedCases: number
    totalCases: number
  }
  studentUI?: {
    hint: string
    concept: string
    explanation: string
    resourceLink?: string
  }
  error?: string
}

const HELLO_WORLD_CODE = `#include <iostream>
using namespace std;

int main() {
    // Write your C++ code here
    cout << "Hello, World!" << endl;
    return 0;
}`

const IDEPage = () => {
  // ============ State ============
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [selectedAssignmentId, setSelectedAssignmentId] = useState<string | null>(null)
  const [expandedAssignmentId, setExpandedAssignmentId] = useState<string | null>(null)
  const [selectedProblem, setSelectedProblem] = useState<string | null>(null)
  const [problem, setProblem] = useState<Problem | null>(null)
  const [code, setCode] = useState(HELLO_WORLD_CODE)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [result, setResult] = useState<SubmissionResult | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isLoadingAssignments, setIsLoadingAssignments] = useState(true)
  const [expandedExplanation, setExpandedExplanation] = useState(false)
  const [completedProblems, setCompletedProblems] = useState<Set<string>>(new Set())

  // ============ Config ============
  const studentId = "student_001"
  const classroomId = "cpp-core"

  // ============ Load Assignments + Completed Problems ============
  useEffect(() => {
    const loadAssignments = async () => {
      try {
        setIsLoadingAssignments(true)
        console.log("📚 Loading assignments for classroom:", classroomId)

        // Load assignments and submission history in parallel
        const [response, subResponse] = await Promise.all([
          api.getClassroomAssignments(classroomId),
          api.getStudentSubmissions(studentId, classroomId) as Promise<{ submissions: any[] }>,
        ])

        // Build set of completed problem IDs (score >= 80)
        const subData = (subResponse as any)?.submissions ?? []
        const completed = new Set<string>(
          subData
            .filter((s: any) => s.score >= 80)
            .map((s: any) => s.problemId)
        )
        setCompletedProblems(completed)
        console.log(`✅ Completed problems: ${completed.size}`)

        console.log("📚 Assignments response:", response)

        if (response?.assignments && Array.isArray(response.assignments)) {
          // Deduplicate by ID
          const uniqueAssignments = Array.from(
            new Map(response.assignments.map((a: Assignment) => [a.id, a])).values()
          ) as Assignment[]

          setAssignments(uniqueAssignments)
          console.log(`✅ Loaded ${uniqueAssignments.length} assignments`)

          if (uniqueAssignments.length > 0) {
            const firstAssignment = uniqueAssignments[0]
            setSelectedAssignmentId(firstAssignment.id)
            setExpandedAssignmentId(firstAssignment.id)  // auto-expand so problems are visible
            
            // Auto-select first problem from first assignment
            const firstProblems = firstAssignment.problems || []
            if (firstProblems.length > 0) {
              setSelectedProblem(firstProblems[0].id)
            }
          }
        } else {
          console.warn("⚠️ No assignments in response:", response)
          setAssignments([])
        }
      } catch (err) {
        console.error("❌ Error loading assignments:", err)
        setError(`Failed to load assignments: ${err instanceof Error ? err.message : "Unknown error"}`)
        setAssignments([])
      } finally {
        setIsLoadingAssignments(false)
      }
    }

    loadAssignments()
  }, [])

  // ============ Load Problem Details ============
  useEffect(() => {
    const loadProblem = async () => {
      if (!selectedProblem) {
        setProblem(null)
        setCode(HELLO_WORLD_CODE)
        setResult(null)
        return
      }

      try {
        console.log(`📖 Loading problem details for ${selectedProblem}`)
        const problemData = await api.getProblem(selectedProblem)
        console.log("📖 Problem details:", problemData)

        const p = (problemData as any).problem ?? problemData
        if (p) {
          setProblem(p)
          setCode(HELLO_WORLD_CODE)
          setResult(null)
          setError(null)
          setExpandedExplanation(false)
        }
      } catch (err) {
        console.error("❌ Error loading problem:", err)
        setError(`Failed to load problem: ${err instanceof Error ? err.message : "Unknown error"}`)
      }
    }

    loadProblem()
  }, [selectedProblem])

  // ============ Submit Code ============
  const handleSubmit = async () => {
    if (!selectedProblem || !code.trim()) {
      setError("Please select a problem and write some code")
      return
    }

    try {
      setIsSubmitting(true)
      setError(null)
      setExpandedExplanation(false)
      console.log(`🚀 Submitting code for problem ${selectedProblem}`)

      const response = await api.submitCode(studentId, selectedProblem, classroomId, code)
      console.log("🚀 Submission response:", response)

      setResult(response)

      // Mark problem as completed instantly if score >= 80
      if (response.metrics?.score >= 80 && selectedProblem) {
        setCompletedProblems(prev => new Set([...prev, selectedProblem]))
      }

      if (response.error) {
        setError(response.error)
      }
    } catch (err) {
      console.error("❌ Submission error:", err)
      setError(`Submission failed: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setIsSubmitting(false)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty?.toLowerCase()) {
      case "easy":
        return "text-green-400"
      case "medium":
        return "text-yellow-400"
      case "hard":
        return "text-red-400"
      default:
        return "text-gray-400"
    }
  }

  const formatDifficulty = (difficulty: string) => {
    return difficulty.charAt(0).toUpperCase() + difficulty.slice(1).toLowerCase()
  }

  // ============ Render ============
  return (
    <div className="flex min-h-screen bg-[#1a1a1e]">
      {/* Main Content */}
      <div className="flex-1 flex flex-col w-full">
        {/* Header */}
        <div className="bg-[#2a2a2e] border-b border-[#424242] px-6 py-3 flex items-center justify-between sticky top-0 z-10">
          <h1 className="text-white font-semibold text-lg">Student IDE</h1>

          <div className="flex items-center gap-4">
            {result && (
              <div
                className={`flex items-center gap-2 px-4 py-1.5 rounded-lg ${
                  result.status === "success"
                    ? "bg-green-900/30 text-green-400"
                    : "bg-red-900/30 text-red-400"
                }`}
              >
                <Trophy size={18} />
                <span className="font-bold text-lg">{result.metrics.score}%</span>
              </div>
            )}

            <button
              onClick={handleSubmit}
              disabled={isSubmitting || !problem}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 px-5 py-1.5 rounded-lg font-semibold text-white text-sm transition"
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={18} className="animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Play size={18} />
                  Submit Code
                </>
              )}
            </button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {/* LEFT: Assignment & Problems Panel */}
          <div className="w-72 bg-[#2b2d30] border-r border-[#424242] flex flex-col overflow-hidden flex-shrink-0">
            {/* Back Button */}
            <div className="p-3 border-b border-[#424242]">
              <Link
                href="/dashboard/student"
                className="block w-full text-center bg-gray-700 hover:bg-gray-600 py-2 rounded text-xs transition text-white font-medium"
              >
                Back to Dashboard
              </Link>
            </div>

            {/* Assignments List */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {isLoadingAssignments ? (
                <div className="p-4 text-center text-gray-400 text-xs">
                  <Loader2 size={16} className="animate-spin mx-auto mb-2" />
                  Loading assignments...
                </div>
              ) : assignments.length === 0 ? (
                <div className="p-3 text-center text-gray-400 text-xs">
                  <AlertCircle size={16} className="mx-auto mb-2" />
                  <p>No assignments</p>
                </div>
              ) : (
                assignments.map((assignment) => {
                  const assignmentProblems = assignment.problems || []
                  const isSelected = selectedAssignmentId === assignment.id
                  const isExpanded = expandedAssignmentId === assignment.id

                  return (
                    <div
                      key={assignment.id}
                      className={`rounded border transition ${
                        isSelected
                          ? "bg-[#1a1a1e] border-[#3a3a3e] border-l-2 border-l-blue-500 text-white"
                          : "bg-[#1a1a1e] border-[#424242] text-gray-400 hover:border-[#5a5a5e]"
                      }`}
                    >
                      {/* Assignment Header - NOT nested buttons */}
                      <div className="w-full text-left p-3 flex items-center justify-between gap-2">
                        {/* Left: Assignment info */}
                        <button
                          onClick={() => {
                            setSelectedAssignmentId(assignment.id)
                            setExpandedAssignmentId(assignment.id)  // always expand on click
                            if (assignmentProblems.length > 0 && !selectedProblem) {
                              setSelectedProblem(assignmentProblems[0].id)
                            }
                          }}
                          className="flex-1 text-left hover:opacity-80 py-0"
                        >
                          <p className="font-semibold text-sm line-clamp-2">
                            {assignment.name || assignment.classroomId}
                          </p>
                          <p className="text-xs opacity-75 mt-0.5">
                            {assignmentProblems.filter(p => completedProblems.has(p.id)).length}/{assignmentProblems.length} completed
                          </p>
                        </button>

                        {/* Right: Expand button */}
                        <button
                          onClick={() => {
                            setExpandedAssignmentId(isExpanded ? null : assignment.id)
                            // Also select the assignment when expanding
                            if (!isSelected) {
                              setSelectedAssignmentId(assignment.id)
                            }
                          }}
                          className="p-1 hover:bg-black/20 rounded flex-shrink-0"
                        >
                          {isExpanded ? (
                            <ChevronUp size={16} />
                          ) : (
                            <ChevronDown size={16} />
                          )}
                        </button>
                      </div>

                      {/* Expandable Problems List */}
                      {isExpanded && assignmentProblems.length > 0 && (
                        <div className="border-t border-current/20 p-2 space-y-1 bg-black/10">
                          {assignmentProblems.map((p) => (
                            <button
                              key={p.id}
                              onClick={() => setSelectedProblem(p.id)}
                              className={`w-full text-left p-2 rounded text-xs transition-all border-l-[3px] ${
                                selectedProblem === p.id
                                  ? "bg-blue-600/30 border-blue-400 text-white shadow-[inset_0_0_0_1px_rgba(96,165,250,0.2)]"
                                  : completedProblems.has(p.id)
                                  ? "border-green-500/60 text-gray-300 hover:bg-white/5 hover:border-green-400"
                                  : "border-transparent text-gray-400 hover:bg-white/5 hover:border-blue-600/40 hover:text-gray-200"
                              }`}
                            >
                              <div className="flex items-center justify-between gap-1">
                                <p className="font-medium line-clamp-1 flex-1">{p.title}</p>
                                {/* Right badge: completed ✅ takes priority, then active ✏️ */}
                                {completedProblems.has(p.id) ? (
                                  <CheckCircle2 size={13} className="text-green-400 shrink-0" />
                                ) : selectedProblem === p.id ? (
                                  <span className="text-[9px] bg-blue-500 text-white px-1.5 py-0.5 rounded font-bold shrink-0">✏️</span>
                                ) : null}
                              </div>
                              <span className={`text-[10px] inline-block mt-0.5 ${getDifficultyColor(p.difficulty)}`}>
                                {formatDifficulty(p.difficulty)}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })
              )}
            </div>
          </div>

          {/* MIDDLE-LEFT: Problem Description Panel */}
          <div className="w-72 bg-[#1e1f23] border-r border-[#424242] flex flex-col overflow-hidden flex-shrink-0">
            <div className="p-4 border-b border-[#424242] bg-[#2b2d30]">
              <h3 className="text-white font-semibold text-xs flex items-center gap-1.5">
                📋 Problem Description
              </h3>
            </div>
            <div className="flex-1 overflow-y-auto p-5">
              {!problem ? (
                <p className="text-gray-500 text-xs text-center pt-8">
                  Select a problem to see its description
                </p>
              ) : (
                <div className="space-y-4">
                  {/* Title + badges */}
                  <div>
                    <h4 className="text-white font-bold text-sm leading-snug">{problem.title}</h4>
                    <div className="flex items-center gap-2 mt-2">
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        problem.difficulty?.toLowerCase() === "easy"   ? "bg-green-900/40 text-green-400" :
                        problem.difficulty?.toLowerCase() === "medium" ? "bg-yellow-900/40 text-yellow-400" :
                                                                          "bg-red-900/40 text-red-400"
                      }`}>
                        {problem.difficulty?.charAt(0).toUpperCase()}{problem.difficulty?.slice(1).toLowerCase()}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-900/30 text-blue-400">
                        {problem.concept}
                      </span>
                    </div>
                  </div>

                  {/* Divider */}
                  <div className="border-t border-[#424242]" />

                  {/* Description */}
                  <div>
                    <p className="text-gray-400 text-[10px] font-semibold uppercase tracking-wide mb-2">📝 โจทย์</p>
                    <p className="text-gray-300 text-xs leading-relaxed whitespace-pre-wrap">
                      {problem.description}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* MIDDLE: Code Editor */}
          <div className="flex-1 flex flex-col bg-[#1a1a1e] overflow-hidden">
            <div className="flex-1 overflow-hidden">
              {problem ? (
                <Editor
                  height="100%"
                  defaultLanguage="cpp"
                  theme="vs-dark"
                  value={code}
                  onChange={(value) => setCode(value || "")}
                  options={{
                    minimap: { enabled: false },
                    fontSize: 14,
                    fontFamily: "Fira Code, monospace",
                    automaticLayout: true,
                    padding: { top: 16 },
                  }}
                />
              ) : (
                <div className="flex items-center justify-center h-full text-gray-400">
                  <p>Select an assignment and problem to start coding</p>
                </div>
              )}
            </div>
          </div>

          {/* RIGHT: AI Feedback Panel */}
          <div className="w-80 bg-[#2b2d30] border-l border-[#424242] flex flex-col overflow-hidden flex-shrink-0">
            {/* Header */}
            <div className="p-4 border-b border-[#424242] bg-[#1a1a1e]">
              <h3 className="text-white font-bold text-sm flex items-center gap-2">
                <Lightbulb size={18} className="text-yellow-400" />
                AI Feedback
              </h3>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {!result ? (
                <p className="text-gray-500 text-xs text-center py-8">
                  Submit your code to get AI feedback
                </p>
              ) : error ? (
                <div className="p-3 rounded-lg bg-red-900/20 border border-red-700 text-red-300 text-xs">
                  <p className="font-semibold flex items-center gap-2">
                    <AlertCircle size={14} />
                    Error
                  </p>
                  <p className="mt-2">{error}</p>
                </div>
              ) : (
                <>
                  {/* Score & Results */}
                  <div
                    className={`p-3 rounded-lg border text-xs ${
                      result.status === "success"
                        ? "bg-green-900/20 border-green-700"
                        : "bg-red-900/20 border-red-700"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span
                        className={`font-bold ${
                          result.status === "success" ? "text-green-400" : "text-red-400"
                        }`}
                      >
                        {result.status === "success" ? "✅ Passed" : "❌ Failed"}
                      </span>
                      <span
                        className={`font-bold text-lg ${
                          result.status === "success" ? "text-green-400" : "text-red-400"
                        }`}
                      >
                        {result.metrics.score}%
                      </span>
                    </div>
                    <div className="text-[11px] text-gray-300 space-y-1">
                      <p>Tests: {result.metrics.passedCases}/{result.metrics.totalCases}</p>
                      <p>Runtime: {result.metrics.runtime}s</p>
                      <p>File size: {result.metrics.fileSize} bytes</p>
                    </div>
                  </div>

                  {/* AI Hint & Explanation */}
                  {result.studentUI && result.status !== "success" && (
                    <>
                      {/* Hint */}
                      <div className="p-3 rounded-lg bg-blue-900/20 border border-blue-700">
                        <p className="text-blue-400 text-xs font-semibold mb-1">💡 Hint</p>
                        <p className="text-gray-300 text-xs leading-tight">
                          {result.studentUI.hint}
                        </p>
                        <p className="text-blue-400 text-xs mt-2 font-semibold">
                          {result.studentUI.concept}
                        </p>
                      </div>

                      {/* Expandable Explanation */}
                      <button
                        onClick={() => setExpandedExplanation(!expandedExplanation)}
                        className="w-full p-3 rounded-lg bg-yellow-900/20 border border-yellow-700 hover:bg-yellow-900/30 transition text-left text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-yellow-400 font-semibold">
                            📖 อธิบายเพิ่มเติม
                          </span>
                          {expandedExplanation ? (
                            <ChevronUp size={14} className="text-yellow-400" />
                          ) : (
                            <ChevronDown size={14} className="text-yellow-400" />
                          )}
                        </div>
                      </button>

                      {/* Expanded Explanation */}
                      {expandedExplanation && (
                        <div className="p-3 rounded-lg bg-[#1a1a1e] border border-yellow-700/30">
                          <p className="text-gray-300 text-xs leading-relaxed whitespace-pre-wrap">
                            {result.studentUI.explanation}
                          </p>
                        </div>
                      )}

                      {/* Resource Link */}
                      {result.studentUI.resourceLink && (
                        <a
                          href={result.studentUI.resourceLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 w-full p-3 rounded-lg bg-purple-900/20 border border-purple-700 hover:bg-purple-900/30 transition text-xs text-purple-300 font-semibold"
                        >
                          <BookOpen size={14} />
                          📚 ศึกษาเพิ่มเติม: {result.studentUI.concept}
                        </a>
                      )}
                    </>
                  )}

                  {/* Success Message */}
                  {result.status === "success" && (
                    <div className="p-3 rounded-lg bg-green-900/20 border border-green-700 text-center">
                      <p className="text-green-400 font-bold text-xs">🎉 All Tests Passed!</p>
                      <p className="text-green-300 text-xs mt-1">Great job!</p>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default IDEPage