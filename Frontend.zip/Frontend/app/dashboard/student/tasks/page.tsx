"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import { useState, useEffect } from "react"
import { api } from "@/lib/api"
import {
  Search,
  Eye,
  Play,
  Clock,
  X,
  BookOpen,
  BarChart2,
  Calendar,
  Loader2,
  AlertCircle,
  CheckCircle2,
} from "lucide-react"
import Link from "next/link"

const STUDENT_ID = "student_001"

const CLASSROOM_NAMES: Record<string, string> = {
  "cpp-core": "C++ Core Language",
  "data-structures": "Data Structures",
  "algorithms": "Algorithm Design",
}

interface Problem {
  id: string
  title: string
  difficulty: string
}

interface Assignment {
  id: string
  name?: string
  classroomId: string
  problemIds: string[]
  problems?: Problem[]
  mode: "guided" | "free"
  dueDate: string
  description?: string
  createdAt?: string
}

interface Submission {
  problemId: string
  score: number
  status: string
  submittedAt?: string
}

const difficultyColors: Record<string, string> = {
  easy: "#4ad991",
  medium: "#fec53d",
  hard: "#f93c65",
}

const modeLabels: Record<string, string> = {
  guided: "Required",
  free: "Optional",
}

function AssignmentModal({
  assignment,
  submissions,
  onClose,
}: {
  assignment: Assignment
  submissions: Submission[]
  onClose: () => void
}) {
  const dueDate = new Date(assignment.dueDate)
  const formattedDate = dueDate.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  })

  const problems = assignment.problems || []
  const completedCount = problems.filter((p) =>
    submissions.some((s) => s.problemId === p.id && s.score >= 80)
  ).length
  const isFullyCompleted = completedCount === problems.length && problems.length > 0

  function formatDifficulty(d: string) {
    return d.charAt(0).toUpperCase() + d.slice(1).toLowerCase()
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.7)" }}
    >
      <div
        className="bg-[#2b2d30] rounded-2xl w-full max-w-xl max-h-[85vh] flex flex-col border border-[#3f4046] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-[#3f4046]">
          <div className="flex flex-col gap-2 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              {isFullyCompleted && (
                <span
                  className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                  style={{ color: "#4ad991", background: "#4ad99122" }}
                >
                  ✅ Completed
                </span>
              )}
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#363d43] text-[#acadb9]">
                {modeLabels[assignment.mode]}
              </span>
            </div>
            <h2 className="text-white font-bold text-lg">
              {assignment.name || "Unnamed Assignment"}
            </h2>
            <div className="flex items-center gap-4 flex-wrap">
              <span className="flex items-center gap-1.5 text-[#acadb9] text-xs">
                <BookOpen className="w-3.5 h-3.5" />
                {CLASSROOM_NAMES[assignment.classroomId] || assignment.classroomId}
              </span>
              <span className="flex items-center gap-1.5 text-[#acadb9] text-xs">
                <Calendar className="w-3.5 h-3.5" />
                Due {formattedDate}
              </span>
              <span className="text-[#acadb9] text-xs">
                {completedCount}/{problems.length} completed
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#696969] hover:text-white hover:bg-[#363d43] rounded-lg transition-colors ml-4"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-5">
          {/* Description */}
          {assignment.description && (
            <div>
              <h3 className="text-white font-semibold text-sm mb-2">
                Description
              </h3>
              <p className="text-[#acadb9] text-sm leading-relaxed">
                {assignment.description}
              </p>
            </div>
          )}

          {/* Problems */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-3">
              Problems ({problems.length})
            </h3>
            <div className="space-y-2">
              {problems.length > 0 ? (
                problems.map((problem) => {
                  const submission = submissions.find(
                    (s) => s.problemId === problem.id
                  )
                  const isCompleted = submission && submission.score >= 80

                  return (
                    <div
                      key={problem.id}
                      className="bg-[#1c1c1e] rounded p-3 border border-[#3f4046]"
                    >
                      <div className="flex items-start justify-between mb-1">
                        <div className="flex items-center gap-2 flex-1">
                          {isCompleted ? (
                            <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                          ) : submission ? (
                            <div className="w-4 h-4 rounded-full border-2 border-yellow-400" />
                          ) : (
                            <div className="w-4 h-4 rounded-full border border-[#3f4046]" />
                          )}
                          <p className="text-white text-xs font-semibold">
                            {problem.title}
                          </p>
                        </div>
                        <span
                          className="text-[10px] px-2 py-0.5 rounded-full font-medium ml-2"
                          style={{
                            color: difficultyColors[problem.difficulty.toLowerCase()],
                            background:
                              difficultyColors[problem.difficulty.toLowerCase()] +
                              "22",
                          }}
                        >
                          {formatDifficulty(problem.difficulty)}
                        </span>
                      </div>
                      <p className="text-[#696969] text-[10px]">{problem.id}</p>
                      {submission && (
                        <p className="text-[#696969] text-[10px] mt-1">
                          Best score: <span className="text-white font-medium">{submission.score}%</span>
                        </p>
                      )}
                    </div>
                  )
                })
              ) : (
                <p className="text-[#696969] text-xs">No problems assigned</p>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#3f4046] p-6 bg-[#1c1c1e] flex gap-3">
          <button className="flex items-center gap-1.5 text-[#acadb9] text-sm px-4 py-2 rounded-lg bg-[#363d43] hover:bg-[#3f4046] transition-colors flex-1">
            <BarChart2 className="w-3.5 h-3.5" />
            View Details
          </button>
          {!isFullyCompleted && (
            <Link
              href="/dashboard/student/ide"
              className="flex items-center gap-1.5 text-[#4880ff] text-sm px-4 py-2 rounded-lg bg-[#4880ff]/10 hover:bg-[#4880ff]/20 border border-[#4880ff]/30 transition-colors flex-1"
            >
              <Play className="w-3.5 h-3.5" />
              Continue
            </Link>
          )}
        </div>
      </div>
    </div>
  )
}

export default function StudentTasksPage() {
  const [allAssignments, setAllAssignments] = useState<Assignment[]>([])
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [search, setSearch] = useState("")
  const [selected, setSelected] = useState<Assignment | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Load assignments from all classrooms
  useEffect(() => {
    const loadAssignments = async () => {
      try {
        setIsLoading(true)
        setError(null)
        console.log("📚 Loading student assignments...")

        // Load from all classrooms
        const classrooms = ["cpp-core", "data-structures", "algorithms"]
        const allAssignmentsData: Assignment[] = []
        const allSubmissionsData: Submission[] = []

        for (const classroomId of classrooms) {
          try {
            console.log(`📖 Loading from ${classroomId}...`)
            const [assignRes, subRes] = await Promise.all([
              api.getClassroomAssignments(classroomId) as Promise<{ assignments: Assignment[] }>,
              api.getStudentSubmissions(STUDENT_ID, classroomId) as Promise<{ submissions: Submission[] }>,
            ])
            
            if (assignRes?.assignments) {
              allAssignmentsData.push(...assignRes.assignments)
              console.log(`✅ Got ${assignRes.assignments.length} assignments from ${classroomId}`)
            }
            
            if (subRes?.submissions) {
              allSubmissionsData.push(...subRes.submissions)
              console.log(`✅ Got ${subRes.submissions.length} submissions from ${classroomId}`)
            }
          } catch (err) {
            console.warn(`⚠️ Failed to load from ${classroomId}:`, err)
          }
        }

        console.log(`✅ Total: ${allAssignmentsData.length} assignments, ${allSubmissionsData.length} submissions`)
        setAllAssignments(allAssignmentsData)
        setSubmissions(allSubmissionsData)
      } catch (err) {
        console.error("❌ Error:", err)
        setError(
          `Failed to load: ${err instanceof Error ? err.message : "Unknown error"}`
        )
      } finally {
        setIsLoading(false)
      }
    }

    loadAssignments()
  }, [])

  // Get assignment status - FIXED: check if ANY problem has submission
  function getAssignmentStatus(a: Assignment) {
    const problems = a.problems || []
    
    // Count problems with ANY submission (even if score < 80)
    const submittedCount = problems.filter((p) =>
      submissions.some((s) => s.problemId === p.id)
    ).length
    
    // Count problems with passing score
    const completedCount = problems.filter((p) =>
      submissions.some((s) => s.problemId === p.id && s.score >= 80)
    ).length

    if (problems.length === 0) return "no-problems"
    if (completedCount === problems.length) return "completed"
    if (submittedCount > 0) return "in-progress"  // ✅ FIXED: if ANY submitted
    return "not-started"
  }

  // Filter logic
  const filtered = allAssignments.filter((a) => {
    if (!search) return true

    const searchLower = search.toLowerCase()

    // Search in assignment name
    if (a.name?.toLowerCase().includes(searchLower)) return true

    // Search in problems
    const problems = a.problems || []
    const hasProblemMatch = problems.some((p) =>
      p.title.toLowerCase().includes(searchLower) ||
      p.id.toLowerCase().includes(searchLower)
    )

    // Search in classroom
    const hasClassroomMatch = (
      CLASSROOM_NAMES[a.classroomId] || a.classroomId
    )
      .toLowerCase()
      .includes(searchLower)

    return hasProblemMatch || hasClassroomMatch
  })

  // Stats
  const stats = [
    {
      label: "Total Assignments",
      value: allAssignments.length,
      color: "#acadb9",
    },
    {
      label: "Completed",
      value: allAssignments.filter((a) => getAssignmentStatus(a) === "completed")
        .length,
      color: "#4ad991",
    },
    {
      label: "In Progress",
      value: allAssignments.filter((a) => getAssignmentStatus(a) === "in-progress")
        .length,
      color: "#fec53d",
    },
    {
      label: "Not Started",
      value: allAssignments.filter((a) => getAssignmentStatus(a) === "not-started")
        .length,
      color: "#f93c65",
    },
  ]

  function formatDifficulty(d: string) {
    return d.charAt(0).toUpperCase() + d.slice(1).toLowerCase()
  }

  function getStatusBadge(status: string) {
    switch (status) {
      case "completed":
        return { label: "✅ Completed", color: "#4ad991", bg: "#4ad99122" }
      case "in-progress":
        return { label: "⏳ In Progress", color: "#fec53d", bg: "#fec53d22" }
      case "not-started":
        return { label: "⭕ Not Started", color: "#f93c65", bg: "#f93c6522" }
      default:
        return { label: "—", color: "#696969", bg: "#69696922" }
    }
  }

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar role="student" />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-white font-bold text-xl">Your Assignments</h2>
              <p className="text-[#696969] text-sm mt-0.5">
                Track your assignments across all classrooms
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-5">
            {stats.map((s) => (
              <div key={s.label} className="bg-[#2b2d30] rounded-xl p-4">
                <p className="text-[#696969] text-xs mb-1">{s.label}</p>
                <p className="font-bold text-2xl" style={{ color: s.color }}>
                  {s.value}
                </p>
              </div>
            ))}
          </div>

          {/* Search */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#696969]" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search assignments..."
                className="w-full bg-[#2b2d30] border border-[#3f4046] rounded-xl pl-9 pr-4 py-2.5 text-white text-sm placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] transition-colors"
              />
            </div>
          </div>

          {/* Error */}
          {error && (
            <div className="mb-4 p-4 bg-red-900/20 border border-red-700 rounded-xl flex gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-400 font-semibold text-sm">Error</p>
                <p className="text-red-300 text-xs mt-1">{error}</p>
              </div>
            </div>
          )}

          {/* Loading */}
          {isLoading && (
            <div className="flex items-center justify-center p-12">
              <div className="text-center">
                <Loader2 className="w-8 h-8 text-[#4880ff] animate-spin mx-auto mb-3" />
                <p className="text-[#696969] text-sm">Loading assignments...</p>
              </div>
            </div>
          )}

          {/* Empty */}
          {!isLoading && filtered.length === 0 && (
            <div className="flex items-center justify-center p-12 bg-[#2b2d30] rounded-2xl">
              <div className="text-center">
                <AlertCircle className="w-8 h-8 text-[#696969] mx-auto mb-3" />
                <p className="text-[#696969] text-sm">
                  {allAssignments.length === 0
                    ? "No assignments yet"
                    : "No results found"}
                </p>
              </div>
            </div>
          )}

          {/* Table */}
          {!isLoading && filtered.length > 0 && (
            <div className="bg-[#2b2d30] rounded-2xl p-5">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#3f4046]">
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Assignment
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Classroom
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Status
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Score
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Due Date
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((a) => {
                      const problems = a.problems || []
                      const completedCount = problems.filter((p) =>
                        submissions.some((s) => s.problemId === p.id && s.score >= 80)
                      ).length
                      const status = getAssignmentStatus(a)
                      const statusBadge = getStatusBadge(status)
                      
                      // Get average score of submitted problems
                      const submittedProblems = problems.filter((p) =>
                        submissions.some((s) => s.problemId === p.id)
                      )
                      const avgScore =
                        submittedProblems.length > 0
                          ? Math.round(
                              submittedProblems.reduce(
                                (sum, p) => {
                                  const sub = submissions.find(
                                    (s) => s.problemId === p.id
                                  )
                                  return sum + (sub?.score || 0)
                                },
                                0
                              ) / submittedProblems.length
                            )
                          : 0

                      return (
                        <tr
                          key={a.id}
                          onClick={() => setSelected(a)}
                          className="border-b border-[#3f4046]/50 hover:bg-[#363d43]/40 transition-colors cursor-pointer group"
                        >
                          <td className="py-3 pr-4">
                            <span className="text-white text-xs font-medium group-hover:text-[#4880ff] transition-colors">
                              {a.name || "Unnamed"}
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            <span className="text-[#acadb9] text-xs">
                              {CLASSROOM_NAMES[a.classroomId] || a.classroomId}
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            <span
                              className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                              style={{
                                color: statusBadge.color,
                                background: statusBadge.bg,
                              }}
                            >
                              {statusBadge.label}
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            <span
                              className="text-xs font-medium"
                              style={{
                                color:
                                  avgScore >= 80
                                    ? "#4ad991"
                                    : avgScore > 0
                                      ? "#fec53d"
                                      : "#696969",
                              }}
                            >
                              {avgScore > 0 ? `${avgScore}%` : "—"}
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            <span className="flex items-center gap-1 text-[#acadb9] text-xs">
                              <Clock className="w-3 h-3" />
                              {new Date(a.dueDate).toLocaleDateString("en-US", {
                                month: "short",
                                day: "numeric",
                              })}
                            </span>
                          </td>
                          <td className="py-3">
                            <div
                              className="flex items-center gap-2"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {status === "completed" ? (
                                <button
                                  onClick={() => setSelected(a)}
                                  className="text-[#4880ff] text-xs hover:underline flex items-center gap-1"
                                >
                                  <Eye className="w-3 h-3" /> Review
                                </button>
                              ) : (
                                <Link
                                  href="/dashboard/student/ide"
                                  className="text-[#4880ff] text-xs hover:underline flex items-center gap-1"
                                >
                                  <Play className="w-3 h-3" /> Start
                                </Link>
                              )}
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>

      {selected && (
        <div onClick={() => setSelected(null)}>
          <AssignmentModal
            assignment={selected}
            submissions={submissions}
            onClose={() => setSelected(null)}
          />
        </div>
      )}
    </div>
  )
}