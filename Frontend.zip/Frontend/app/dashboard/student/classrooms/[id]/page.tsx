"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import Link from "next/link"
import { ChevronRight, Clock, CheckCircle2, Circle, Play, Eye, Loader2, AlertCircle, TimerOff } from "lucide-react"
import { use, useState, useEffect } from "react"
import { api } from "@/lib/api"

// ── Types ─────────────────────────────────────────────────────────────────────
interface ProblemInAssignment {
  id: string
  title: string
  difficulty: string
}

interface Assignment {
  id: string
  name?: string
  classroomId: string
  problemIds: string[]
  problems?: ProblemInAssignment[]
  mode: "guided" | "free"
  dueDate?: string
  description?: string
}

interface StudentSubmission {
  id: string
  problemId: string
  status: string
  score: number
  submittedAt: string
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const STUDENT_ID = "student_001"
const MAX_STUDENTS = 30

const CLASSROOM_META: Record<string, { name: string; code: string; color: string; teacher: string; description: string }> = {
  "cpp-core": {
    name: "C++ Core Language", code: "CS101", color: "#4880ff",
    teacher: "Prof. Sarah Chen",
    description: "Fundamental C++ programming concepts: variables, loops, functions, arrays and pointers.",
  },
  "data-structures": {
    name: "Data Structures", code: "CS102", color: "#4ad991",
    teacher: "Dr. Mike Johnson",
    description: "Linked lists, stacks, queues, trees and hash tables implemented in C++.",
  },
  "algorithms": {
    name: "Algorithm Design", code: "CS201", color: "#fec53d",
    teacher: "Prof. Anna Lee",
    description: "Sorting, searching, dynamic programming and graph algorithms in C++.",
  },
}

const difficultyColors: Record<string, string> = {
  easy: "#4ad991", medium: "#fec53d", hard: "#f93c65",
}
function diffColor(d: string) { return difficultyColors[d?.toLowerCase()] ?? "#696969" }

function formatDate(dateStr?: string) {
  if (!dateStr) return "No deadline"
  return new Date(dateStr).toLocaleDateString("en-GB", { day: "numeric", month: "short" }) +
    " · " + new Date(dateStr).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
}

function getAssignmentStatus(assignment: Assignment, submissions: StudentSubmission[]) {
  const now = new Date()
  const due = assignment.dueDate ? new Date(assignment.dueDate) : null
  const assignmentProblems = assignment.problems ?? []
  const completedCount = assignmentProblems.filter(p =>
    submissions.some(s => s.problemId === p.id && s.score >= 80)
  ).length
  const total = assignmentProblems.length

  if (total > 0 && completedCount >= total) {
    return { label: "Completed", color: "#4ad991", bg: "#4ad99120", icon: "check" as const }
  }
  if (due && now > due) {
    return { label: "Times Up", color: "#f93c65", bg: "#f93c6520", icon: "timesup" as const }
  }
  if (completedCount > 0) {
    return { label: "In Progress", color: "#4880ff", bg: "#4880ff20", icon: "progress" as const }
  }
  return { label: "Pending", color: "#fec53d", bg: "#fec53d20", icon: "pending" as const }
}

function getProblemStatus(problemId: string, submissions: StudentSubmission[]) {
  const best = submissions
    .filter(s => s.problemId === problemId)
    .sort((a, b) => b.score - a.score)[0]
  if (!best) return { label: "Not Started", color: "#696969", score: null }
  if (best.score >= 80) return { label: "Completed", color: "#4ad991", score: best.score }
  return { label: "In Progress", color: "#fec53d", score: best.score }
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function StudentClassroomDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const meta = CLASSROOM_META[id] ?? { name: id, code: id, color: "#4880ff", teacher: "", description: "" }

  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [submissions, setSubmissions] = useState<StudentSubmission[]>([])
  const [loading, setLoading] = useState(true)
  const [fetchError, setFetchError] = useState<string | null>(null)
  const [expandedId, setExpandedId] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true)
        const [assignRes, subRes] = await Promise.all([
          api.getClassroomAssignments(id) as Promise<{ assignments: Assignment[] }>,
          api.getStudentSubmissions(STUDENT_ID, id) as Promise<{ submissions: StudentSubmission[] }>,
        ])
        const loaded = assignRes.assignments ?? []
        setAssignments(loaded)
        setSubmissions(subRes.submissions ?? [])
        // Auto-expand first assignment
        if (loaded.length > 0) setExpandedId(loaded[0].id)
      } catch {
        setFetchError("Cannot reach backend — make sure it's running on port 3001")
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [id])

  // Progress = problems completed across all assignments / total problems
  const allProblems = assignments.flatMap(a => a.problems ?? [])
  const uniqueProblems = [...new Map(allProblems.map(p => [p.id, p])).values()]
  const completedCount = uniqueProblems.filter(p =>
    submissions.some(s => s.problemId === p.id && s.score >= 80)
  ).length
  const progress = uniqueProblems.length > 0 ? Math.round((completedCount / uniqueProblems.length) * 100) : 0

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar role="student" />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6">

          {/* Breadcrumb */}
          <div className="flex items-center gap-2 mb-4">
            <Link href="/dashboard/student/classrooms" className="text-[#696969] text-xs hover:text-white transition-colors">
              Classrooms
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-[#696969]" />
            <span className="text-white text-xs">{meta.name}</span>
          </div>

          {/* Error */}
          {fetchError && (
            <div className="flex items-center gap-2 bg-red-900/20 border border-red-700 text-red-300 text-xs px-4 py-3 rounded-xl mb-5">
              <AlertCircle className="w-4 h-4 shrink-0" /> {fetchError}
            </div>
          )}

          {/* Header card */}
          <div className="bg-[#2b2d30] rounded-2xl p-6 mb-5">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: meta.color }} />
                  <h2 className="text-white font-bold text-xl">{meta.name}</h2>
                  <span className="text-xs px-2 py-0.5 rounded bg-[#363d43] text-[#acadb9]">{meta.code}</span>
                </div>
                <p className="text-[#696969] text-sm mt-1">{meta.teacher}</p>
                <p className="text-[#acadb9] text-xs mt-2 leading-relaxed max-w-lg">{meta.description}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-[#696969] text-xs">Your Progress</p>
                <p className="text-white font-bold text-3xl mt-1" style={{ color: meta.color }}>{loading ? "—" : `${progress}%`}</p>
                <p className="text-[#acadb9] text-xs mt-1">{loading ? "..." : `${completedCount}/${uniqueProblems.length} completed`}</p>
              </div>
            </div>
            <div className="mt-4 h-2 bg-[#363d43] rounded-full">
              <div className="h-2 rounded-full transition-all duration-500"
                style={{ width: `${loading ? 0 : progress}%`, background: meta.color }} />
            </div>
          </div>

          {/* Assignments */}
          <div className="bg-[#2b2d30] rounded-2xl p-5">
            <h3 className="text-white font-semibold text-sm mb-4">Assignments</h3>

            {loading ? (
              <div className="flex justify-center py-12"><Loader2 className="w-5 h-5 text-[#4880ff] animate-spin" /></div>
            ) : assignments.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-[#696969] text-sm">No assignments yet</p>
                <p className="text-[#696969] text-xs mt-1">Your teacher hasn't created any assignments</p>
              </div>
            ) : (
              <div className="space-y-2">
                {assignments.map((a) => {
                  const isExpanded = expandedId === a.id
                  const status = getAssignmentStatus(a, submissions)
                  const assignmentProblems = a.problems ?? []
                  const doneInAssignment = assignmentProblems.filter(p =>
                    submissions.some(s => s.problemId === p.id && s.score >= 80)
                  ).length

                  return (
                    <div key={a.id} className="rounded-xl border border-[#3f4046] overflow-hidden">
                      {/* Header row — click to expand */}
                      <button
                        onClick={() => setExpandedId(isExpanded ? null : a.id)}
                        className="w-full text-left px-4 py-3 flex items-center gap-3 hover:bg-[#363d43]/40 transition-colors"
                      >
                        <ChevronRight className={`w-3.5 h-3.5 text-[#696969] transition-transform shrink-0 ${isExpanded ? "rotate-90" : ""}`} />

                        {/* Assignment name */}
                        <span className="text-white text-sm font-medium flex-1">{a.name || "Unnamed Assignment"}</span>

                        {/* Progress fraction */}
                        <span className="text-[#696969] text-xs shrink-0">{doneInAssignment}/{assignmentProblems.length} done</span>

                        {/* Mode */}
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-medium capitalize shrink-0"
                          style={{ color: a.mode === "guided" ? "#4880ff" : "#4ad991", background: a.mode === "guided" ? "#4880ff22" : "#4ad99122" }}>
                          {a.mode}
                        </span>

                        {/* Status badge */}
                        <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full shrink-0"
                          style={{ color: status.color, background: status.bg }}>
                          {status.icon === "check"    && <CheckCircle2 className="w-3 h-3" />}
                          {status.icon === "timesup"  && <TimerOff className="w-3 h-3" />}
                          {status.icon === "progress" && <Clock className="w-3 h-3" />}
                          {status.icon === "pending"  && <Circle className="w-3 h-3" />}
                          {status.label}
                        </span>

                        {/* Due date */}
                        {a.dueDate && (
                          <span className="flex items-center gap-1 text-[#696969] text-xs shrink-0">
                            <Clock className="w-3 h-3" />{formatDate(a.dueDate)}
                          </span>
                        )}
                      </button>

                      {/* Expanded: problems table */}
                      {isExpanded && (
                        <div className="border-t border-[#3f4046] bg-[#1c1c1e] px-4 py-3">
                          {a.description && (
                            <p className="text-[#acadb9] text-xs mb-3 leading-relaxed">{a.description}</p>
                          )}
                          {assignmentProblems.length === 0 ? (
                            <p className="text-[#696969] text-xs">
                              {a.mode === "free" ? "Free mode — all problems are accessible from the IDE" : "No problems in this assignment"}
                            </p>
                          ) : (
                            <table className="w-full">
                              <thead>
                                <tr className="border-b border-[#3f4046]">
                                  <th className="text-left text-[#696969] text-[10px] font-medium pb-2 pr-4">Problem</th>
                                  <th className="text-left text-[#696969] text-[10px] font-medium pb-2 pr-4">Difficulty</th>
                                  <th className="text-left text-[#696969] text-[10px] font-medium pb-2 pr-4">Status</th>
                                  <th className="text-left text-[#696969] text-[10px] font-medium pb-2 pr-4">Score</th>
                                  <th className="text-left text-[#696969] text-[10px] font-medium pb-2 pr-4">Due</th>
                                  <th className="text-left text-[#696969] text-[10px] font-medium pb-2">Action</th>
                                </tr>
                              </thead>
                              <tbody>
                                {assignmentProblems.map((p) => {
                                  const dc = diffColor(p.difficulty)
                                  const ps = getProblemStatus(p.id, submissions)
                                  const isDone = ps.label === "Completed"
                                  return (
                                    <tr key={p.id} className="border-b border-[#3f4046]/30 hover:bg-[#363d43]/20 transition-colors">
                                      <td className="py-2 pr-4">
                                        <div className="flex items-center gap-1.5">
                                          {isDone
                                            ? <CheckCircle2 className="w-3.5 h-3.5 text-[#4ad991] shrink-0" />
                                            : <Circle className="w-3.5 h-3.5 text-[#696969] shrink-0" />
                                          }
                                          <span className="text-white text-xs">{p.title}</span>
                                        </div>
                                      </td>
                                      <td className="py-2 pr-4">
                                        <span className="text-[9px] px-1.5 py-0.5 rounded-full capitalize"
                                          style={{ color: dc, background: dc + "22" }}>
                                          {p.difficulty}
                                        </span>
                                      </td>
                                      <td className="py-2 pr-4">
                                        <span className="text-xs" style={{ color: ps.color }}>{ps.label}</span>
                                      </td>
                                      <td className="py-2 pr-4">
                                        <span className="text-xs text-white">
                                          {ps.score !== null ? `${ps.score}/100` : <span className="text-[#696969]">—</span>}
                                        </span>
                                      </td>
                                      <td className="py-2 pr-4">
                                        <span className="text-[#696969] text-xs">{formatDate(a.dueDate)}</span>
                                      </td>
                                      <td className="py-2">
                                        <Link href="/dashboard/student/ide"
                                          className="flex items-center gap-1 text-xs font-medium transition-colors"
                                          style={{ color: isDone ? "#4ad991" : "#4880ff" }}>
                                          {isDone
                                            ? <><Eye className="w-3 h-3" /> Review</>
                                            : <><Play className="w-3 h-3" /> Start</>
                                          }
                                        </Link>
                                      </td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            </table>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>

        </main>
      </div>
    </div>
  )
}