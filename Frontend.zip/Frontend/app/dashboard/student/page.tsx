"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import { useState, useEffect } from "react"
import { api } from "@/lib/api"
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts"
import { TrendingUp, Flame, Trophy, ChevronRight, Code2, Clock, CheckCircle2, Loader2, AlertCircle } from "lucide-react"
import Link from "next/link"

const STUDENT_ID = "student_001"
const CLASSROOM_ID = "cpp-core"

const statusColors: Record<string, string> = {
  success: "#4ad991",
  compile_error: "#f93c65",
  runtime_error: "#fec53d",
  logic_error: "#4880ff",
}

const statusLabels: Record<string, string> = {
  success: "Passed",
  compile_error: "Compile Error",
  runtime_error: "Runtime Error",
  logic_error: "Logic Error",
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return "just now"
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  return `${Math.floor(hrs / 24)}d ago`
}

export default function StudentDashboard() {
  const [dashData, setDashData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true)
        const data = await (api as any).getStudentDashboard(STUDENT_ID, CLASSROOM_ID)
        setDashData(data)
      } catch (err) {
        setError("Cannot reach backend — make sure it's running on port 3001")
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const stats = dashData?.stats ?? {}
  const activityData = dashData?.activityData ?? Array.from({ length: 12 }, (_, i) => ({
    month: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][i],
    submissions: 0,
  }))
  const recentSubmissions: any[] = dashData?.recentSubmissions ?? []

  const progressPct = stats.totalProblems > 0
    ? Math.round((stats.completedProblems / stats.totalProblems) * 100)
    : 0
// /${stats.totalProblems ?? 0}
  const statsCards = [
    {
      label: "Problems Solved",
      value: loading ? "—" : `${stats.completedProblems ?? 0}`,
      icon: Code2,
      color: "#4880ff",
      bg: "#1a2a4a",
    },
    {
      label: "Total Submissions",
      value: loading ? "—" : String(stats.totalSubmissions ?? 0),
      icon: TrendingUp,
      color: "#4ad991",
      bg: "#1a3a2a",
    },
    {
      label: "Streak",
      value: loading ? "—" : String(stats.streak ?? 0),
      icon: Flame,
      color: "#fec53d",
      bg: "#3a2a1a",
      suffix: "Days",
    },
    {
      label: "Rank",
      value: "#67",
      icon: Trophy,
      color: "#f93c65",
      bg: "#3a1a2a",
      note: "Leaderboard soon",
    },
  ]

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar role="student" userName="John Doe" userEmail="john@example.com" />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6 flex flex-col gap-5">

          {/* Welcome */}
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-white font-bold text-xl">Student Dashboard</h2>
              <p className="text-[#696969] text-sm mt-0.5">Welcome back, John!</p>
            </div>
            <Link
              href="/dashboard/student/ide"
              className="flex items-center gap-2 bg-[#4880ff] hover:bg-[#3d72f0] text-white text-xs font-medium px-4 py-2 rounded-xl transition-colors"
            >
              <Code2 className="w-3.5 h-3.5" />
              Open IDE
            </Link>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-center gap-2 bg-red-900/20 border border-red-700 text-red-300 text-xs px-4 py-3 rounded-xl">
              <AlertCircle className="w-4 h-4 shrink-0" /> {error}
            </div>
          )}

          {/* Top row: Activity chart + Progress */}
          <div className="grid grid-cols-3 gap-5">
            {/* Activity Chart */}
            <div className="col-span-2 bg-[#2b2d30] rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-semibold text-sm">Your Submission Activity</h3>
                {loading && <Loader2 className="w-4 h-4 text-[#4880ff] animate-spin" />}
              </div>
              <ResponsiveContainer width="100%" height={140}>
                <AreaChart data={activityData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorSubs" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4880ff" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#4880ff" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#3f4046" vertical={false} />
                  <XAxis dataKey="month" tick={{ fill: "#696969", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "#696969", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: "#363d43", border: "1px solid #3f4046", borderRadius: 8, color: "#fff", fontSize: 12 }}
                    cursor={{ stroke: "#4880ff", strokeWidth: 1 }}
                  />
                  <Area type="monotone" dataKey="submissions" stroke="#4880ff" strokeWidth={2} fill="url(#colorSubs)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Progress card */}
            <div className="bg-[#2b2d30] rounded-2xl p-5 flex flex-col gap-4">
              <h3 className="text-white font-semibold text-sm">C++ Core Progress</h3>
              {loading ? (
                <div className="flex-1 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-[#4880ff] animate-spin" />
                </div>
              ) : (
                <>
                  <div className="flex items-end gap-2">
                    <p className="text-white font-bold text-4xl" style={{ color: "#4880ff" }}>{progressPct}%</p>
                    <p className="text-[#696969] text-xs mb-1">{stats.completedProblems} solved</p>
                  </div>
                  <div className="h-2 bg-[#363d43] rounded-full">
                    <div className="h-2 rounded-full transition-all duration-700"
                      style={{ width: `${progressPct}%`, background: "#4880ff" }} />
                  </div>
                  <Link href="/dashboard/student/classrooms/cpp-core"
                    className="flex items-center gap-1 text-[#4880ff] text-xs hover:underline mt-auto">
                    View Assignments <ChevronRight className="w-3 h-3" />
                  </Link>
                </>
              )}
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-4 gap-4">
            {statsCards.map((stat) => {
              const Icon = stat.icon
              return (
                <div key={stat.label} className="bg-[#2b2d30] rounded-2xl p-4 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: stat.bg }}>
                      <Icon className="w-4 h-4" style={{ color: stat.color }} />
                    </div>
                    <span className="text-[#696969] text-[10px] text-right">{stat.label}</span>
                  </div>
                  <div>
                    <p className="text-white font-bold text-xl">{stat.value}</p>
                    {stat.suffix && <p className="text-[#696969] text-xs">{stat.suffix}</p>}
                    {stat.note && <p className="text-[#696969] text-[10px]">{stat.note}</p>}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Recent Submissions */}
          <div className="bg-[#2b2d30] rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold text-sm">Recent Submissions</h3>
              <Link href="/dashboard/student/ide" className="flex items-center gap-1 text-[#4880ff] text-xs hover:underline">
                Open IDE <ChevronRight className="w-3 h-3" />
              </Link>
            </div>

            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-5 h-5 text-[#4880ff] animate-spin" />
              </div>
            ) : recentSubmissions.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-[#696969] text-sm">No submissions yet</p>
                <p className="text-[#696969] text-xs mt-1">Submit your first solution in the IDE!</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#3f4046]">
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">Problem</th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">Result</th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">Score</th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">Concept</th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3">When</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentSubmissions.map((s: any) => {
                      const isPassed = s.status === "success"
                      const statusColor = statusColors[s.status] ?? "#696969"
                      return (
                        <tr key={s.id} className="border-b border-[#3f4046]/50 hover:bg-[#363d43]/30 transition-colors">
                          <td className="py-3 pr-4">
                            <div className="flex items-center gap-1.5">
                              {isPassed
                                ? <CheckCircle2 className="w-3.5 h-3.5 text-[#4ad991] shrink-0" />
                                : <span className="w-3.5 h-3.5 rounded-full border-2 border-[#696969] shrink-0 inline-block" />
                              }
                              <span className="text-white text-xs font-medium">{s.problemTitle}</span>
                            </div>
                          </td>
                          <td className="py-3 pr-4">
                            <span className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                              style={{ color: statusColor, background: statusColor + "20" }}>
                              {statusLabels[s.status] ?? s.status}
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            <span className="text-white text-xs font-semibold">
                              {s.score}<span className="text-[#696969] font-normal">/100</span>
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            {s.aiConcept
                              ? <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-900/30 text-blue-400">{s.aiConcept}</span>
                              : <span className="text-[#696969] text-xs">—</span>
                            }
                          </td>
                          <td className="py-3">
                            <span className="flex items-center gap-1 text-[#696969] text-xs">
                              <Clock className="w-3 h-3" />{timeAgo(s.submittedAt)}
                            </span>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </main>
      </div>
    </div>
  )
}