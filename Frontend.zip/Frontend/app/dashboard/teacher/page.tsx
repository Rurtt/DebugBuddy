"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar, Cell,
} from "recharts"
import { ChevronRight, Users, BookOpen, CheckSquare, TrendingUp, Plus, AlertCircle, Loader2 } from "lucide-react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { api } from "@/lib/api"

// ── Types ─────────────────────────────────────────────────────────────────────
interface StudentStat {
  studentId: string
  problemId: string
  totalSubmissions: number
  bestScore: number
  successRate: number
  strugglingConcepts: { concept: string; count: number }[]
}
interface RecentError {
  submissionId: string
  studentId: string
  problemId: string
  status: string
  score: number
  concept?: string
  submittedAt: string
}
interface DashboardData {
  studentStats: StudentStat[]
  problemStats: { problemId: string; successRate: number; commonErrors: { concept: string; count: number }[] }[]
  recentErrors: RecentError[]
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const CONCEPT_COLORS = ["#f93c65", "#fec53d", "#4880ff", "#4ad991", "#ff9066"]

function scoreColor(score: number) {
  if (score >= 90) return "#4ad991"
  if (score >= 70) return "#4880ff"
  if (score >= 50) return "#fec53d"
  return "#f93c65"
}
function gradeLabel(score: number) {
  if (score >= 90) return "A"
  if (score >= 80) return "B+"
  if (score >= 70) return "B"
  if (score >= 60) return "C+"
  return "C"
}
function buildScoreDist(stats: StudentStat[]) {
  const best = new Map<string, number>()
  for (const s of stats) {
    const prev = best.get(s.studentId) ?? 0
    if (s.bestScore > prev) best.set(s.studentId, s.bestScore)
  }
  const buckets = [
    { range: "0-20",   count: 0, color: "#f93c65" },
    { range: "21-40",  count: 0, color: "#ff9066" },
    { range: "41-60",  count: 0, color: "#fec53d" },
    { range: "61-80",  count: 0, color: "#4ad991" },
    { range: "81-100", count: 0, color: "#4880ff" },
  ]
  for (const score of best.values()) {
    if (score <= 20) buckets[0].count++
    else if (score <= 40) buckets[1].count++
    else if (score <= 60) buckets[2].count++
    else if (score <= 80) buckets[3].count++
    else buckets[4].count++
  }
  return buckets
}
function buildTopConcepts(stats: StudentStat[]) {
  const map = new Map<string, number>()
  for (const s of stats)
    for (const c of s.strugglingConcepts)
      map.set(c.concept, (map.get(c.concept) ?? 0) + c.count)
  return Array.from(map.entries())
    .sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([concept, count]) => ({ concept, count }))
}
function buildErrorTypes(errors: RecentError[]) {
  const c = { compile_error: 0, runtime_error: 0, logic_error: 0 }
  for (const e of errors) if (e.status in c) c[e.status as keyof typeof c]++
  const total = c.compile_error + c.runtime_error + c.logic_error || 1
  return [
    { label: "Syntax",  count: c.compile_error,  color: "#f93c65", pct: Math.round(c.compile_error / total * 100) },
    { label: "Runtime", count: c.runtime_error,  color: "#fec53d", pct: Math.round(c.runtime_error / total * 100) },
    { label: "Logic",   count: c.logic_error,    color: "#4880ff", pct: Math.round(c.logic_error / total * 100) },
  ]
}
// Splits errors into 4 weekly buckets, counting occurrences of each top concept
function buildErrorTrend(errors: RecentError[], topConcepts: { concept: string }[]) {
  const keys = topConcepts.slice(0, 3).map(c => c.concept)
  const weeks = ["Week 1", "Week 2", "Week 3", "Week 4"]
  const chunk = Math.ceil(errors.length / 4) || 1
  return weeks.map((name, wi) => {
    const slice = errors.slice(wi * chunk, (wi + 1) * chunk)
    const row: Record<string, string | number> = { name }
    for (const key of keys) row[key] = slice.filter(e => e.concept === key).length
    return row
  })
}

// ── Component ─────────────────────────────────────────────────────────────────
type Tab = "overview" | "errors" | "submissions"
const CLASSROOM_ID = "cpp-core"

export default function TeacherDashboard() {
  const router = useRouter()
  const [tab, setTab] = useState<Tab>("overview")
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [fetchError, setFetchError] = useState<string | null>(null)

  useEffect(() => {
    api.getClassroomDashboard(CLASSROOM_ID)
      .then(res => setData(res as DashboardData))
      .catch(() => setFetchError("Cannot reach backend — make sure it's running on port 3001"))
      .finally(() => setLoading(false))
  }, [])

  // ── Derived ──────────────────────────────────────────────────────────────
  const studentRows = data
    ? Array.from(
        data.studentStats.reduce((map, s) => {
          const prev = map.get(s.studentId)
          if (!prev || s.bestScore > prev.bestScore) map.set(s.studentId, s)
          return map
        }, new Map<string, StudentStat>()).values()
      ).sort((a, b) => b.bestScore - a.bestScore)
    : []

  const totalStudents    = studentRows.length
  const totalSubmissions = data?.studentStats.reduce((s, x) => s + x.totalSubmissions, 0) ?? 0
  const avgScore         = studentRows.length ? Math.round(studentRows.reduce((s, x) => s + x.bestScore, 0) / studentRows.length) : 0
  const totalErrors      = data?.recentErrors.length ?? 0

  const scoreDist      = data ? buildScoreDist(data.studentStats) : []
  const topConcepts    = data ? buildTopConcepts(data.studentStats) : []
  const errorTypes     = data ? buildErrorTypes(data.recentErrors) : []
  const maxConcept     = topConcepts[0]?.count || 1
  const topConceptKeys = topConcepts.slice(0, 3).map(c => c.concept)
  const errorTrendData = data
    ? buildErrorTrend(data.recentErrors, topConcepts)
    : [{ name: "Week 1" }, { name: "Week 2" }, { name: "Week 3" }, { name: "Week 4" }]

  const statsCards = [
    { label: "Total Students",    value: String(totalStudents),    icon: Users,       color: "#4880ff", bg: "#1a2a4a", sub: "Unique Students" },
    { label: "Total Submissions", value: String(totalSubmissions), icon: CheckSquare, color: "#4ad991", bg: "#1a3a2a", sub: "All Time" },
    { label: "Avg Best Score",    value: `${avgScore}%`,           icon: TrendingUp,  color: "#fec53d", bg: "#3a2a1a", sub: "Across All Students" },
    { label: "Recent Errors",     value: String(totalErrors),      icon: BookOpen,    color: "#f93c65", bg: "#3a1a2a", sub: "Last 20 Submissions" },
  ]

  const Spinner = () => (
    <div className="flex justify-center py-10">
      <Loader2 className="w-5 h-5 text-[#4880ff] animate-spin" />
    </div>
  )

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar role="teacher" userName="Prof. Sarah Chen" userEmail="sarah@university.ac.th" />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6 flex flex-col gap-5">

          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-white font-bold text-xl">{"Teacher's Dashboard"}</h2>
              <p className="text-[#696969] text-sm mt-0.5">C++ Core Language — {CLASSROOM_ID}</p>
            </div>
            {/* Goes to classrooms list first, not directly to cpp-core */}
            <button
              onClick={() => router.push("/dashboard/teacher/classrooms")}
              className="flex items-center gap-2 bg-[#4880ff] hover:bg-[#3d72f0] text-white text-xs font-medium px-4 py-2 rounded-lg transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> New Assignment
            </button>
          </div>

          {/* Error banner */}
          {fetchError && (
            <div className="flex items-center gap-2 bg-red-900/20 border border-red-700 text-red-300 text-xs px-4 py-3 rounded-xl">
              <AlertCircle className="w-4 h-4 shrink-0" /> {fetchError}
            </div>
          )}

          {/* Stats cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {statsCards.map((stat) => {
              const Icon = stat.icon
              return (
                <div key={stat.label} className="bg-[#2b2d30] rounded-2xl p-4 flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: stat.bg }}>
                      <Icon className="w-4 h-4" style={{ color: stat.color }} />
                    </div>
                    <span className="text-[#696969] text-[10px] text-right leading-tight">{stat.label}</span>
                  </div>
                  <div>
                    {loading
                      ? <div className="w-12 h-6 bg-[#363d43] rounded animate-pulse" />
                      : <p className="text-white font-bold text-2xl">{stat.value}</p>}
                    <p className="text-[#4ad991] text-[10px] mt-0.5">{stat.sub}</p>
                  </div>
                </div>
              )
            })}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-[#2b2d30] rounded-xl p-1 w-fit">
            {(["overview", "errors", "submissions"] as Tab[]).map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all capitalize ${
                  tab === t ? "bg-[#4880ff] text-white" : "text-[#696969] hover:text-[#acadb9]"
                }`}>
                {t === "errors" ? "Error Analytics" : t}
              </button>
            ))}
          </div>

          {/* ── OVERVIEW ── */}
          {tab === "overview" && (
            <>
              {/* TOP STUDENT ERRORS area chart */}
              <div className="bg-[#2b2d30] rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-white font-semibold text-sm">Top Student Errors</h3>
                    <p className="text-[#696969] text-xs mt-0.5">Most frequent error concepts across recent submissions</p>
                  </div>
                  <div className="flex items-center gap-4">
                    {topConceptKeys.length > 0
                      ? topConceptKeys.map((key, i) => (
                          <div key={key} className="flex items-center gap-1.5">
                            <div className="w-2 h-2 rounded-full" style={{ background: CONCEPT_COLORS[i] }} />
                            <span className="text-[#696969] text-xs">{key}</span>
                          </div>
                        ))
                      : !loading && <span className="text-[#696969] text-xs italic">Submit some code to see error trends</span>
                    }
                  </div>
                </div>
                {loading ? <Spinner /> : (
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={errorTrendData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                      <defs>
                        {topConceptKeys.map((key, i) => (
                          <linearGradient key={key} id={`gErr${i}`} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%"  stopColor={CONCEPT_COLORS[i]} stopOpacity={0.55} />
                            <stop offset="95%" stopColor={CONCEPT_COLORS[i]} stopOpacity={0.05} />
                          </linearGradient>
                        ))}
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#3f4046" vertical={false} />
                      <XAxis dataKey="name" tick={{ fill: "#696969", fontSize: 11 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: "#696969", fontSize: 10 }} axisLine={false} tickLine={false} allowDecimals={false} />
                      <Tooltip contentStyle={{ background: "#363d43", border: "1px solid #3f4046", borderRadius: 8, color: "#fff", fontSize: 12 }} cursor={{ stroke: "#4880ff", strokeWidth: 1 }} />
                      {topConceptKeys.map((key, i) => (
                        <Area key={key} type="monotone" dataKey={key}
                          stroke={CONCEPT_COLORS[i]} strokeWidth={2}
                          fill={`url(#gErr${i})`} name={key} />
                      ))}
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>

              {/* Student table + Score dist */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="md:col-span-2 bg-[#2b2d30] rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-white font-semibold text-sm">Student Progress</h3>
                    <button onClick={() => setTab("submissions")} className="flex items-center gap-1 text-[#4880ff] text-xs hover:underline">
                      View Submissions <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                  {loading ? <Spinner /> : studentRows.length === 0 ? (
                    <p className="text-[#696969] text-xs text-center py-8">No submissions yet</p>
                  ) : (
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-[#3f4046]">
                          {["Student", "Best Score", "Submissions", "Top Struggle", "Grade"].map(h => (
                            <th key={h} className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {studentRows.map((s) => (
                          <tr key={s.studentId} className="border-b border-[#3f4046]/50 hover:bg-[#363d43]/30 transition-colors">
                            <td className="py-2.5 pr-4">
                              <div className="flex items-center gap-2">
                                <div className="w-7 h-7 rounded-full bg-[#4880ff] flex items-center justify-center text-white text-xs font-bold shrink-0">
                                  {s.studentId.charAt(0).toUpperCase()}
                                </div>
                                <span className="text-white text-xs font-mono">{s.studentId}</span>
                              </div>
                            </td>
                            <td className="py-2.5 pr-4">
                              <div className="flex items-center gap-2">
                                <div className="w-16 h-1.5 bg-[#363d43] rounded-full">
                                  <div className="h-1.5 rounded-full" style={{ width: `${s.bestScore}%`, background: scoreColor(s.bestScore) }} />
                                </div>
                                <span className="text-white text-xs">{s.bestScore}</span>
                              </div>
                            </td>
                            <td className="py-2.5 pr-4 text-[#acadb9] text-xs">{s.totalSubmissions}</td>
                            <td className="py-2.5 pr-4">
                              {s.strugglingConcepts[0]
                                ? <span className="text-xs px-2 py-0.5 rounded bg-red-900/30 text-red-300">{s.strugglingConcepts[0].concept}</span>
                                : <span className="text-[#696969] text-xs">—</span>}
                            </td>
                            <td className="py-2.5">
                              <span className="text-xs px-2 py-0.5 rounded bg-[#363d43] text-white">{gradeLabel(s.bestScore)}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>

                <div className="bg-[#2b2d30] rounded-2xl p-5 flex flex-col gap-4">
                  <h3 className="text-white font-semibold text-sm">Score Distribution</h3>
                  {loading ? <Spinner /> : (
                    <div className="flex flex-col gap-3">
                      {scoreDist.map((d) => {
                        const max = Math.max(...scoreDist.map(x => x.count), 1)
                        return (
                          <div key={d.range} className="flex items-center gap-3">
                            <span className="text-[#696969] text-xs w-12 shrink-0">{d.range}</span>
                            <div className="flex-1 h-2 bg-[#363d43] rounded-full">
                              <div className="h-2 rounded-full" style={{ width: `${(d.count / max) * 100}%`, background: d.color }} />
                            </div>
                            <span className="text-white text-xs w-4 text-right shrink-0">{d.count}</span>
                          </div>
                        )
                      })}
                    </div>
                  )}
                  <div className="mt-auto pt-4 border-t border-[#3f4046]">
                    <p className="text-[#696969] text-xs">Total Students</p>
                    <p className="text-white font-bold text-2xl mt-1">{loading ? "—" : totalStudents}</p>
                    <p className="text-[#4ad991] text-xs mt-1">{loading ? "" : `${totalSubmissions} total submissions`}</p>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* ── ERROR ANALYTICS ── */}
          {tab === "errors" && (
            <div className="flex flex-col gap-5">
              <div className="grid grid-cols-3 gap-4">
                {loading ? <div className="col-span-3"><Spinner /></div> : errorTypes.map((e) => (
                  <div key={e.label} className="bg-[#2b2d30] rounded-2xl p-5">
                    <p className="text-[#696969] text-xs mb-1">{e.label} Errors</p>
                    <p className="text-white font-bold text-3xl">{e.count}</p>
                    <div className="mt-3 h-1.5 bg-[#363d43] rounded-full">
                      <div className="h-1.5 rounded-full" style={{ width: `${e.pct}%`, background: e.color }} />
                    </div>
                    <p className="text-xs mt-1" style={{ color: e.color }}>{e.pct}% of all errors</p>
                  </div>
                ))}
              </div>

              <div className="bg-[#2b2d30] rounded-2xl p-5">
                <h3 className="text-white font-semibold text-sm mb-1">Top Struggling Concepts</h3>
                <p className="text-[#696969] text-xs mb-4">Concepts students are failing on most</p>
                {loading ? <Spinner /> : topConcepts.length === 0 ? (
                  <p className="text-[#696969] text-xs text-center py-8">No error data yet</p>
                ) : (
                  <>
                    <div className="flex flex-col gap-3 mb-6">
                      {topConcepts.map((c, i) => (
                        <div key={c.concept} className="flex items-center gap-3">
                          <span className="text-[#696969] text-xs w-4 shrink-0">#{i + 1}</span>
                          <span className="text-white text-xs w-40 shrink-0">{c.concept}</span>
                          <div className="flex-1 h-2.5 bg-[#363d43] rounded-full">
                            <div className="h-2.5 rounded-full" style={{ width: `${(c.count / maxConcept) * 100}%`, background: CONCEPT_COLORS[i] }} />
                          </div>
                          <span className="text-white text-xs w-8 text-right shrink-0">{c.count}×</span>
                        </div>
                      ))}
                    </div>
                    <ResponsiveContainer width="100%" height={150}>
                      <BarChart data={topConcepts} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#3f4046" vertical={false} />
                        <XAxis dataKey="concept" tick={{ fill: "#696969", fontSize: 9 }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fill: "#696969", fontSize: 10 }} axisLine={false} tickLine={false} />
                        <Tooltip contentStyle={{ background: "#363d43", border: "1px solid #3f4046", borderRadius: 8, color: "#fff", fontSize: 12 }} />
                        <Bar dataKey="count" name="Occurrences" radius={[4, 4, 0, 0]}>
                          {topConcepts.map((_, i) => <Cell key={i} fill={CONCEPT_COLORS[i]} />)}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </>
                )}
              </div>

              <div className="bg-[#2b2d30] rounded-2xl p-5">
                <h3 className="text-white font-semibold text-sm mb-4">Per-Student Error Breakdown</h3>
                {loading ? <Spinner /> : studentRows.length === 0 ? (
                  <p className="text-[#696969] text-xs text-center py-8">No data yet</p>
                ) : (
                  <div className="flex flex-col gap-3">
                    {studentRows.map((s) => (
                      <div key={s.studentId} className="bg-[#1c1c1e] rounded-xl p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-[#4880ff] flex items-center justify-center text-white text-xs font-bold">
                              {s.studentId.charAt(0).toUpperCase()}
                            </div>
                            <span className="text-white text-xs font-mono">{s.studentId}</span>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-[#696969]">
                            <span>{s.totalSubmissions} submissions</span>
                            <span className="font-semibold" style={{ color: scoreColor(s.bestScore) }}>{s.bestScore}% best</span>
                          </div>
                        </div>
                        {s.strugglingConcepts.length === 0 ? (
                          <p className="text-[#4ad991] text-xs">✅ No struggling concepts recorded</p>
                        ) : (
                          <div className="flex flex-wrap gap-2">
                            {s.strugglingConcepts.map((c) => (
                              <span key={c.concept} className="text-xs px-2 py-0.5 rounded-full bg-red-900/30 text-red-300">
                                {c.concept} ×{c.count}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── SUBMISSIONS ── */}
          {tab === "submissions" && (
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {!loading && [
                  { label: "Total Submissions", value: totalSubmissions, color: "#4880ff" },
                  { label: "Successful", value: data?.studentStats.reduce((s, x) => s + Math.round(x.successRate / 100 * x.totalSubmissions), 0) ?? 0, color: "#4ad991" },
                  { label: "With Errors", value: totalErrors, color: "#f93c65" },
                  { label: "Unique Students", value: totalStudents, color: "#fec53d" },
                ].map(s => (
                  <div key={s.label} className="bg-[#2b2d30] rounded-2xl p-4">
                    <p className="text-[#696969] text-xs mb-2">{s.label}</p>
                    <p className="font-bold text-2xl" style={{ color: s.color }}>{s.value}</p>
                  </div>
                ))}
              </div>

              <div className="bg-[#2b2d30] rounded-2xl p-5">
                <h3 className="text-white font-semibold text-sm mb-4">Recent Submissions with Errors</h3>
                {loading ? <Spinner /> : totalErrors === 0 ? (
                  <p className="text-[#696969] text-xs text-center py-8">No errors yet 🎉</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-[#3f4046]">
                          {["Student", "Problem", "Error Type", "AI Concept", "Score", "Time"].map(h => (
                            <th key={h} className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {data?.recentErrors.map((e) => {
                          const cols: Record<string, string> = { compile_error: "#f93c65", runtime_error: "#fec53d", logic_error: "#4880ff" }
                          const labs: Record<string, string> = { compile_error: "Syntax", runtime_error: "Runtime", logic_error: "Logic" }
                          const col = cols[e.status] ?? "#696969"
                          return (
                            <tr key={e.submissionId} className="border-b border-[#3f4046]/50 hover:bg-[#363d43]/30 transition-colors">
                              <td className="py-2.5 pr-4 text-white text-xs font-mono">{e.studentId}</td>
                              <td className="py-2.5 pr-4 text-[#acadb9] text-xs">{e.problemId.replace(/_/g, " ")}</td>
                              <td className="py-2.5 pr-4">
                                <span className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ color: col, background: col + "22" }}>
                                  {labs[e.status] ?? e.status}
                                </span>
                              </td>
                              <td className="py-2.5 pr-4">
                                {e.concept
                                  ? <span className="text-xs px-2 py-0.5 rounded bg-red-900/30 text-red-300">{e.concept}</span>
                                  : <span className="text-[#696969] text-xs">—</span>}
                              </td>
                              <td className="py-2.5 pr-4">
                                <span className="text-xs font-semibold" style={{ color: scoreColor(e.score) }}>{e.score}%</span>
                              </td>
                              <td className="py-2.5 text-[#696969] text-xs">
                                {new Date(e.submittedAt).toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" })}
                              </td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  )
}