"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import Link from "next/link"
import { BookOpen, Users, ChevronRight, Plus, FileText, Loader2 } from "lucide-react"
import { useState, useEffect } from "react"
import { api } from "@/lib/api"

const CLASSROOM_CONFIGS = [
  {
    id: "cpp-core",
    name: "C++ Core Language",
    code: "CS101",
    description: "Fundamental C++ programming concepts: variables, loops, functions, arrays and pointers.",
    color: "#4880ff",
    active: true,
  },
  {
    id: "data-structures",
    name: "Data Structures",
    code: "CS102",
    description: "Linked lists, stacks, queues, trees and hash tables implemented in C++.",
    color: "#4ad991",
    active: false,
  },
  {
    id: "algorithms",
    name: "Algorithm Design",
    code: "CS201",
    description: "Sorting, searching, dynamic programming and graph algorithms in C++.",
    color: "#fec53d",
    active: false,
  },
]

const MAX_STUDENTS = 30

export default function TeacherClassroomsPage() {
  const [assignments, setAssignments] = useState<any[]>([])
  const [dashboard, setDashboard] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      try {
        const [assignRes, dashRes] = await Promise.all([
          api.getClassroomAssignments("cpp-core") as Promise<{ assignments: any[] }>,
          api.getClassroomDashboard("cpp-core") as Promise<any>,
        ])
        setAssignments(assignRes.assignments ?? [])
        setDashboard(dashRes)
      } catch {
        // silently fail — we just won't show dynamic data
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  // Dynamic progress: unique students who submitted / MAX_STUDENTS
  const uniqueStudents = dashboard
    ? new Set((dashboard.studentStats ?? []).map((s: any) => s.studentId)).size
    : 0
  const progressPct = Math.min(Math.round((uniqueStudents / MAX_STUDENTS) * 100), 100)

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar role="teacher" userName="Prof. Sarah Chen" userEmail="sarah@university.ac.th" />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-white font-bold text-xl">Your Classrooms</h2>
              <p className="text-[#696969] text-sm mt-0.5">Select a classroom to manage assignments</p>
            </div>
            <button className="flex items-center gap-2 bg-[#4880ff] hover:bg-[#3d72f0] text-white text-sm font-medium px-4 py-2 rounded-xl transition-colors">
              <Plus className="w-4 h-4" />
              Create Classroom
            </button>
          </div>

          <div className="flex flex-col gap-4">
            {CLASSROOM_CONFIGS.map((cls) => (
              <Link
                key={cls.id}
                href={`/dashboard/teacher/classrooms/${cls.id}`}
                className="block bg-[#2b2d30] rounded-2xl p-5 hover:bg-[#363d43] transition-colors group"
              >
                <div className="flex items-start gap-4">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 mt-0.5"
                    style={{ background: cls.color + "20" }}
                  >
                    <BookOpen className="w-6 h-6" style={{ color: cls.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-2">
                        <h3 className="text-white font-semibold text-base">{cls.name}</h3>
                        <span className="text-xs px-2 py-0.5 rounded bg-[#363d43] text-[#acadb9]">{cls.code}</span>
                      </div>
                      <ChevronRight className="w-5 h-5 text-[#696969] group-hover:text-white transition-colors shrink-0" />
                    </div>
                    <p className="text-[#696969] text-xs mt-2 leading-relaxed">{cls.description}</p>

                    {/* Stats row */}
                    <div className="flex items-center gap-6 mt-3">
                      <div className="flex items-center gap-1.5 text-[#acadb9] text-xs">
                        <Users className="w-3.5 h-3.5" />
                        {cls.active
                          ? (loading ? "..." : `${uniqueStudents} student${uniqueStudents !== 1 ? "s" : ""}`)
                          : "0 students"
                        }
                      </div>
                      <div className="flex items-center gap-1.5 text-[#acadb9] text-xs">
                        <FileText className="w-3.5 h-3.5" />
                        <span
                          className="text-xs px-1.5 py-0.5 rounded font-medium"
                          style={{
                            color: cls.active ? "#4880ff" : "#696969",
                            background: cls.active ? "#4880ff22" : "transparent",
                          }}
                        >
                          {cls.active ? "Active" : "Coming soon"}
                        </span>
                      </div>
                    </div>

                    {/* Assignments list — only for active classroom */}
                    {cls.active && (
                      <div className="mt-3">
                        {loading ? (
                          <div className="flex items-center gap-1.5 text-[#696969] text-xs">
                            <Loader2 className="w-3 h-3 animate-spin" /> Loading assignments...
                          </div>
                        ) : assignments.length === 0 ? (
                          <p className="text-[#696969] text-xs">No assignments yet</p>
                        ) : (
                          <div className="flex flex-wrap gap-1.5 mt-0.5">
                            <span className="text-[#696969] text-xs mr-1 self-center">Assignments:</span>
                            {assignments.map((a: any) => (
                              <span
                                key={a.id}
                                className="text-[10px] px-2 py-0.5 rounded-full font-medium border"
                                style={{ color: cls.color, background: cls.color + "15", borderColor: cls.color + "40" }}
                              >
                                {a.name || "Unnamed"}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Dynamic progress bar */}
                    {cls.active && (
                      <div className="flex items-center gap-3 mt-3">
                        <div className="flex-1 h-1.5 bg-[#363d43] rounded-full">
                          <div
                            className="h-1.5 rounded-full transition-all duration-500"
                            style={{ width: `${loading ? 0 : progressPct}%`, background: cls.color }}
                          />
                        </div>
                        <span className="text-[#696969] text-xs shrink-0">
                          {loading ? "..." : `${progressPct}% (${uniqueStudents}/${MAX_STUDENTS} students)`}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}