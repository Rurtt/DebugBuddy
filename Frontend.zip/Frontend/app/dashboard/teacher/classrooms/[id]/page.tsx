"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import Link from "next/link"
import { ChevronRight, Plus, Loader2, AlertCircle, CheckCircle2, Clock, TimerOff } from "lucide-react"
import { use, useState, useEffect } from "react"
import { api } from "@/lib/api"

// ── Types ─────────────────────────────────────────────────────────────────────
interface Problem {
  id: string
  title: string
  difficulty: string
  concept: string
  testCaseCount: number
}

interface Assignment {
  id: string
  name?: string
  classroomId: string
  problemIds: string[]
  problems?: { id: string; title: string; difficulty: string; concept?: string }[]
  mode: "guided" | "free"
  createdAt: string
  dueDate?: string
  description?: string
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const difficultyColors: Record<string, string> = {
  easy:   "#4ad991",
  medium: "#fec53d",
  hard:   "#f93c65",
}
function diffColor(d: string) { return difficultyColors[d?.toLowerCase()] ?? "#696969" }

function formatDate(dateStr?: string) {
  if (!dateStr) return "No deadline"
  return new Date(dateStr).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })
}

// ── Classroom metadata (frontend-only) ────────────────────────────────────────
const CLASSROOM_META: Record<string, { name: string; code: string; color: string }> = {
  "cpp-core":       { name: "C++ Core Language", code: "CS101", color: "#4880ff" },
  "data-structures":{ name: "Data Structures",   code: "CS102", color: "#4ad991" },
  "algorithms":     { name: "Algorithm Design",  code: "CS201", color: "#fec53d" },
}

// ── Component ─────────────────────────────────────────────────────────────────
export default function TeacherClassroomDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const meta = CLASSROOM_META[id] ?? { name: id, code: id, color: "#4880ff" }

  const [problems, setProblems] = useState<Problem[]>([])
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [loading, setLoading] = useState(true)
  const [fetchError, setFetchError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<"problems" | "assignments">("problems")
  const [expandedAssignmentId, setExpandedAssignmentId] = useState<string | null>(null)

  function getAssignmentStatus(dueDate?: string) {
    if (!dueDate) return { label: "Pending", color: "#fec53d", bg: "#fec53d20", icon: "pending" as const }
    const now = new Date(); const due = new Date(dueDate)
    if (now > due) return { label: "Times Up", color: "#f93c65", bg: "#f93c6520", icon: "timesup" as const }
    return { label: "Pending", color: "#fec53d", bg: "#fec53d20", icon: "pending" as const }
  }

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true)
        const [problemsRes, assignmentsRes] = await Promise.all([
          api.getProblems(id) as Promise<{ problems: Problem[]; total: number }>,
          api.getClassroomAssignments(id) as Promise<{ assignments: Assignment[] }>,
        ])
        setProblems(problemsRes.problems ?? [])
        setAssignments(assignmentsRes.assignments ?? [])
      } catch {
        setFetchError("Cannot reach backend — make sure it's running on port 3001")
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [id])

  // Group problems by difficulty for display
  const easy   = problems.filter(p => p.difficulty?.toLowerCase() === "easy")
  const medium = problems.filter(p => p.difficulty?.toLowerCase() === "medium")
  const hard   = problems.filter(p => p.difficulty?.toLowerCase() === "hard")

  const Spinner = () => (
    <div className="flex justify-center py-12">
      <Loader2 className="w-5 h-5 text-[#4880ff] animate-spin" />
    </div>
  )

  const ProblemRow = ({ p, rank }: { p: Problem; rank: number }) => {
    const dc = diffColor(p.difficulty)
    return (
      <tr className="border-b border-[#3f4046]/50 hover:bg-[#363d43]/30 transition-colors">
        <td className="py-3 pr-4 text-[#696969] text-xs w-8">{rank}</td>
        <td className="py-3 pr-4 text-white text-xs font-medium">{p.title}</td>
        <td className="py-3 pr-4">
          <span
            className="text-[10px] px-2 py-0.5 rounded-full font-medium capitalize"
            style={{ color: dc, background: dc + "22" }}
          >
            {p.difficulty}
          </span>
        </td>
        <td className="py-3 pr-4 text-[#acadb9] text-xs">{p.concept}</td>
        <td className="py-3 text-[#696969] text-xs">{p.testCaseCount} tests</td>
      </tr>
    )
  }

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar role="teacher" userName="Prof. Sarah Chen" userEmail="sarah@university.ac.th" />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6">

          {/* Breadcrumb */}
          <div className="flex items-center gap-2 mb-4">
            <Link href="/dashboard/teacher/classrooms" className="text-[#696969] text-xs hover:text-white transition-colors">
              Classrooms
            </Link>
            <ChevronRight className="w-3.5 h-3.5 text-[#696969]" />
            <span className="text-white text-xs">{meta.name}</span>
          </div>

          {/* Error banner */}
          {fetchError && (
            <div className="flex items-center gap-2 bg-red-900/20 border border-red-700 text-red-300 text-xs px-4 py-3 rounded-xl mb-5">
              <AlertCircle className="w-4 h-4 shrink-0" /> {fetchError}
            </div>
          )}

          {/* Header */}
          <div className="bg-[#2b2d30] rounded-2xl p-6 mb-5">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: meta.color }} />
                  <h2 className="text-white font-bold text-xl">{meta.name}</h2>
                  <span className="text-xs px-2 py-0.5 rounded bg-[#363d43] text-[#acadb9]">{meta.code}</span>
                </div>
                <div className="flex items-center gap-4 mt-2">
                  <p className="text-[#acadb9] text-xs">
                    {loading ? "Loading..." : `${problems.length} problems · ${assignments.length} assignment${assignments.length !== 1 ? "s" : ""}`}
                  </p>
                </div>
              </div>
              <Link
                href={`/dashboard/teacher/classrooms/${id}/create-assignment`}
                className="flex items-center gap-2 text-white text-sm font-medium px-4 py-2 rounded-xl transition-colors"
                style={{ background: meta.color }}
              >
                <Plus className="w-4 h-4" />
                Create Assignment
              </Link>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-[#2b2d30] rounded-xl p-1 w-fit mb-5">
            {(["problems", "assignments"] as const).map(t => (
              <button key={t} onClick={() => setActiveTab(t)}
                className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all capitalize ${
                  activeTab === t ? "bg-[#4880ff] text-white" : "text-[#696969] hover:text-[#acadb9]"
                }`}>
                {t} {!loading && t === "problems" && `(${problems.length})`}
                {!loading && t === "assignments" && `(${assignments.length})`}
              </button>
            ))}
          </div>

          {/* ── PROBLEMS TAB ── */}
          {activeTab === "problems" && (
            <div className="flex flex-col gap-4">
              {loading ? <Spinner /> : problems.length === 0 ? (
                <div className="bg-[#2b2d30] rounded-2xl p-12 text-center">
                  <p className="text-[#696969] text-sm">No problems found</p>
                  <p className="text-[#696969] text-xs mt-1">Check that problems.json is loaded in the backend</p>
                </div>
              ) : (
                <>
                  {/* Stats row */}
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { label: "Easy",   count: easy.length,   color: "#4ad991" },
                      { label: "Medium", count: medium.length, color: "#fec53d" },
                      { label: "Hard",   count: hard.length,   color: "#f93c65" },
                    ].map(s => (
                      <div key={s.label} className="bg-[#2b2d30] rounded-2xl p-4">
                        <p className="text-[#696969] text-xs mb-1">{s.label}</p>
                        <p className="text-white font-bold text-2xl">{s.count}</p>
                        <div className="mt-2 h-1 rounded-full" style={{ background: s.color }} />
                      </div>
                    ))}
                  </div>

                  {/* Problems table */}
                  <div className="bg-[#2b2d30] rounded-2xl p-5">
                    <h3 className="text-white font-semibold text-sm mb-4">All Problems</h3>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-[#3f4046]">
                            <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4 w-8">#</th>
                            <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">Title</th>
                            <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">Difficulty</th>
                            <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">Concept</th>
                            <th className="text-left text-[#696969] text-xs font-medium pb-3">Test Cases</th>
                          </tr>
                        </thead>
                        <tbody>
                          {/* Easy section */}
                          {easy.length > 0 && (
                            <tr><td colSpan={5} className="pt-4 pb-2">
                              <span className="text-[10px] font-semibold text-[#4ad991] uppercase tracking-wider">Easy</span>
                            </td></tr>
                          )}
                          {easy.map((p, i) => <ProblemRow key={p.id} p={p} rank={i + 1} />)}

                          {/* Medium section */}
                          {medium.length > 0 && (
                            <tr><td colSpan={5} className="pt-4 pb-2">
                              <span className="text-[10px] font-semibold text-[#fec53d] uppercase tracking-wider">Medium</span>
                            </td></tr>
                          )}
                          {medium.map((p, i) => <ProblemRow key={p.id} p={p} rank={easy.length + i + 1} />)}

                          {/* Hard section */}
                          {hard.length > 0 && (
                            <tr><td colSpan={5} className="pt-4 pb-2">
                              <span className="text-[10px] font-semibold text-[#f93c65] uppercase tracking-wider">Hard</span>
                            </td></tr>
                          )}
                          {hard.map((p, i) => <ProblemRow key={p.id} p={p} rank={easy.length + medium.length + i + 1} />)}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ── ASSIGNMENTS TAB ── */}
          {activeTab === "assignments" && (
            <div className="bg-[#2b2d30] rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-semibold text-sm">Assignments</h3>
                <Link
                  href={`/dashboard/teacher/classrooms/${id}/create-assignment`}
                  className="flex items-center gap-1.5 text-[#4880ff] text-xs hover:underline"
                >
                  <Plus className="w-3.5 h-3.5" /> New
                </Link>
              </div>

              {loading ? <Spinner /> : assignments.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-[#696969] text-sm">No assignments yet</p>
                  <p className="text-[#696969] text-xs mt-1">Create one to assign problems to students</p>
                  <Link
                    href={`/dashboard/teacher/classrooms/${id}/create-assignment`}
                    className="inline-flex items-center gap-2 mt-4 bg-[#4880ff] hover:bg-[#3d72f0] text-white text-xs font-medium px-4 py-2 rounded-lg transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" /> Create Assignment
                  </Link>
                </div>
              ) : (
                <div className="space-y-2">
                  {assignments.map((a) => {
                    const isExpanded = expandedAssignmentId === a.id
                    const status = getAssignmentStatus(a.dueDate)
                    const assignmentProblems = a.problems ?? a.problemIds.map(pid => {
                      const p = problems.find(x => x.id === pid)
                      return p ? { id: pid, title: p.title, difficulty: p.difficulty }
                               : { id: pid, title: pid.replace(/_/g, " "), difficulty: "" }
                    })
                    return (
                      <div key={a.id} className="bg-[#1c1c1e] rounded-2xl border border-[#3f4046] overflow-hidden hover:border-[#5a5a6e] transition-colors group">
                        {/* Card header — click to expand */}
                        <button
                          onClick={() => setExpandedAssignmentId(isExpanded ? null : a.id)}
                          className="w-full text-left p-5 flex items-start gap-4"
                        >
                          {/* Icon block */}
                          <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5"
                            style={{ background: a.mode === "guided" ? "#4880ff22" : "#4ad99122" }}>
                            <span className="text-base">{a.mode === "guided" ? "📋" : "🔓"}</span>
                          </div>

                          {/* Main content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="text-white font-semibold text-sm">{a.name || "Unnamed Assignment"}</h4>
                                <span className="text-[10px] px-2 py-0.5 rounded-full font-medium capitalize"
                                  style={{ color: a.mode === "guided" ? "#4880ff" : "#4ad991", background: a.mode === "guided" ? "#4880ff22" : "#4ad99122" }}>
                                  {a.mode}
                                </span>
                                <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full"
                                  style={{ color: status.color, background: status.bg }}>
                                  {status.icon === "timesup" && <TimerOff className="w-3 h-3" />}
                                  {status.icon === "pending" && <Clock className="w-3 h-3" />}
                                  {status.label}
                                </span>
                              </div>
                              <ChevronRight className={`w-4 h-4 text-[#696969] transition-transform shrink-0 mt-0.5 ${isExpanded ? "rotate-90" : ""}`} />
                            </div>
                            <div className="flex items-center gap-4 mt-2 flex-wrap">
                              <span className="text-[#696969] text-xs">{assignmentProblems.length} problem{assignmentProblems.length !== 1 ? "s" : ""}</span>
                              {a.dueDate && (
                                <span className="flex items-center gap-1 text-[#696969] text-xs">
                                  <Clock className="w-3 h-3" />{formatDate(a.dueDate)}
                                </span>
                              )}
                            </div>
                          </div>
                        </button>

                        {/* Expanded panel */}
                        {isExpanded && (
                          <div className="border-t border-[#3f4046] bg-[#2b2d30] px-5 py-4 space-y-4">
                            {/* Description with label */}
                            {a.description && (
                              <div className="flex gap-2">
                                <span className="text-[#696969] text-xs font-semibold uppercase tracking-wide shrink-0 mt-0.5">📝 คำอธิบาย</span>
                                <p className="text-[#acadb9] text-xs leading-relaxed">{a.description}</p>
                              </div>
                            )}

                            {/* Problems */}
                            {assignmentProblems.length === 0 ? (
                              <p className="text-[#696969] text-xs">
                                {a.mode === "free" ? "🔓 Free mode — students can access all problems" : "No problems assigned"}
                              </p>
                            ) : (
                              <div>
                                <p className="text-[#696969] text-[10px] font-semibold uppercase tracking-wide mb-2">Problems Assigned</p>
                                <div className="space-y-1.5">
                                  {assignmentProblems.map((p) => {
                                    const dc = diffColor(p.difficulty)
                                    return (
                                      <div key={p.id} className="flex items-center gap-2 py-1.5 px-3 rounded-lg bg-[#1c1c1e] border border-[#3f4046]/50">
                                        <span className="text-white text-xs flex-1 font-medium">{p.title}</span>
                                        {p.concept && (
                                          <span className="text-[9px] px-2 py-0.5 rounded-full bg-blue-900/30 text-blue-400 shrink-0">
                                            {p.concept}
                                          </span>
                                        )}
                                        {p.difficulty && (
                                          <span className="text-[9px] px-1.5 py-0.5 rounded-full capitalize shrink-0"
                                            style={{ color: dc, background: dc + "22" }}>
                                            {p.difficulty}
                                          </span>
                                        )}
                                      </div>
                                    )
                                  })}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          )}

        </main>
      </div>
    </div>
  )
}