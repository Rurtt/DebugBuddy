"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import { useState, useEffect } from "react"
import { api } from "@/lib/api"
import { Plus, Check, AlertCircle, Loader2, ChevronLeft } from "lucide-react"
import Link from "next/link"
import { use } from "react"

interface Problem {
  id: string
  title: string
  difficulty: string
  concept: string
}

export default function TeacherCreateAssignmentPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const classroomId = id || "cpp-core"

  const [assignmentName, setAssignmentName] = useState("")
  const [selectedProblems, setSelectedProblems] = useState<string[]>([])
  const [mode, setMode] = useState<"guided" | "free">("guided")
  const [description, setDescription] = useState("")
  const [dueDate, setDueDate] = useState("")
  const [dueTime, setDueTime] = useState("23:59")
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingProblems, setIsLoadingProblems] = useState(true)
  const [problems, setProblems] = useState<Problem[]>([])
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  // ============ Load All Problems ============
  useEffect(() => {
    const loadProblems = async () => {
      try {
        setIsLoadingProblems(true)
        console.log("📚 Loading all problems from backend...")
        const response = await api.getProblems(classroomId)
        console.log("📚 Problems response:", response)

        if (response?.problems && Array.isArray(response.problems)) {
          setProblems(response.problems)
          console.log(`✅ Loaded ${response.problems.length} problems`)
        } else {
          console.warn("⚠️ No problems in response:", response)
          setProblems([])
        }
      } catch (err) {
        console.error("❌ Error loading problems:", err)
        setMessage({
          type: "error",
          text: `Failed to load problems: ${err instanceof Error ? err.message : "Unknown error"}`,
        })
        setProblems([])
      } finally {
        setIsLoadingProblems(false)
      }
    }

    loadProblems()
  }, [])

  const handleToggleProblem = (problemId: string) => {
    setSelectedProblems((prev) =>
      prev.includes(problemId) ? prev.filter((id) => id !== problemId) : [...prev, problemId]
    )
  }

  const handleCreateAssignment = async () => {
    if (!assignmentName.trim()) {
      setMessage({ type: "error", text: "Please enter an assignment name" })
      return
    }

    if (mode === "guided" && selectedProblems.length === 0) {
      setMessage({ type: "error", text: "โหมด Guided ต้องเลือกอย่างน้อย 1 โจทย์" })
      return
    }

    try {
      setIsLoading(true)
      setMessage(null)

      // Combine date and time into a full datetime
      let dueDatetime: Date | undefined = undefined
      if (dueDate) {
        dueDatetime = new Date(`${dueDate}T${dueTime}:00`)
      }

      console.log("📝 Creating assignment:", {
        name: assignmentName,
        problemIds: selectedProblems,
        mode,
        dueDate: dueDatetime,
        description,
      })

      const response = await api.createAssignment(
        classroomId,
        selectedProblems,
        mode,
        dueDatetime,
        description || undefined,
        assignmentName
      )

      console.log("✅ Assignment created:", response)

      setMessage({
        type: "success",
        text: `✅ Assignment "${assignmentName}" created successfully! ${selectedProblems.length} problem(s) assigned.`,
      })

      // Reset form
      setAssignmentName("")
      setSelectedProblems([])
      setMode("guided")
      setDescription("")
      setDueDate("")
      setDueTime("23:59")

      // Auto-clear message after 5 seconds
      setTimeout(() => setMessage(null), 5000)
    } catch (error) {
      console.error("❌ Error creating assignment:", error)
      setMessage({
        type: "error",
        text: `Error creating assignment: ${error instanceof Error ? error.message : "Unknown error"}`,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    const lower = difficulty.toLowerCase()
    switch (lower) {
      case "easy":
        return "bg-green-900/30 text-green-400 border-green-700"
      case "medium":
        return "bg-yellow-900/30 text-yellow-400 border-yellow-700"
      case "hard":
        return "bg-red-900/30 text-red-400 border-red-700"
      default:
        return "bg-gray-900/30 text-gray-400 border-gray-700"
    }
  }

  // Capitalize first letter of difficulty
  const formatDifficulty = (difficulty: string) => {
    return difficulty.charAt(0).toUpperCase() + difficulty.slice(1).toLowerCase()
  }

  // Format datetime for display
  const formatDueDateTime = () => {
    if (!dueDate) return "Not set"
    const date = new Date(dueDate)
    const dateStr = date.toLocaleDateString()
    return `${dateStr} at ${dueTime}`
  }

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar role="teacher" userName="Prof. Sarah Chen" userEmail="sarah@university.ac.th" />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Breadcrumb & Header */}
          <div className="mb-8">
            <Link
              href={`/dashboard/teacher/classrooms/${classroomId}`}
              className="flex items-center gap-2 text-gray-400 hover:text-white mb-4 transition"
            >
              <ChevronLeft className="w-4 h-4" />
              Back to Classroom
            </Link>
            <h1 className="text-3xl font-bold text-white mb-2">Create Assignment</h1>
            <p className="text-gray-400">Create a new assignment for your students</p>
          </div>

          {/* Message Alert */}
          {message && (
            <div
              className={`mb-6 p-4 rounded-lg flex items-center gap-3 ${
                message.type === "success"
                  ? "bg-green-900/20 text-green-300 border border-green-700"
                  : "bg-red-900/20 text-red-300 border border-red-700"
              }`}
            >
              {message.type === "success" ? (
                <Check className="w-5 h-5 shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 shrink-0" />
              )}
              <p>{message.text}</p>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left: Problem Selection */}
            <div className="lg:col-span-2 space-y-6">
              {/* Assignment Settings Card */}
              <div className="bg-[#2b2d30] rounded-xl p-6 border border-[#424242]">
                <h2 className="text-lg font-semibold text-white mb-6">Assignment Settings</h2>

                {/* Assignment Name */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-white mb-2">
                    Assignment Name *
                  </label>
                  <input
                    type="text"
                    value={assignmentName}
                    onChange={(e) => setAssignmentName(e.target.value)}
                    placeholder="ตัวอย่าง: สัปดาห์ที่ 1 - อัลกอริทึมเบื้องต้น"
                    className="w-full px-4 py-2 rounded-lg bg-[#1c1c1e] text-white placeholder-gray-500 border border-[#424242] focus:border-blue-500 outline-none transition"
                  />

                </div>

                {/* Mode Selection */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-white mb-3">Mode</label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        value="guided"
                        checked={mode === "guided"}
                        onChange={(e) => setMode(e.target.value as "guided" | "free")}
                        className="w-4 h-4 accent-blue-500"
                      />
                      <span className="text-gray-300">Guided (Required)</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        value="free"
                        checked={mode === "free"}
                        onChange={(e) => setMode(e.target.value as "guided" | "free")}
                        className="w-4 h-4 accent-blue-500"
                      />
                      <span className="text-gray-300">Free (Optional/Practice)</span>
                    </label>
                  </div>
                </div>

                {/* Description */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-white mb-2">Description (optional)</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Add instructions or notes for this assignment..."
                    className="w-full px-4 py-3 rounded-lg bg-[#1c1c1e] text-white placeholder-gray-500 border border-[#424242] focus:border-blue-500 outline-none transition resize-none"
                    rows={4}
                  />
                </div>

                {/* Due Date & Time */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Due Date (optional)</label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      className="w-full px-4 py-2 rounded-lg bg-[#1c1c1e] text-white border border-[#424242] focus:border-blue-500 outline-none transition"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-white mb-2">Due Time (optional)</label>
                    <input
                      type="time"
                      value={dueTime}
                      onChange={(e) => setDueTime(e.target.value)}
                      disabled={!dueDate}
                      className="w-full px-4 py-2 rounded-lg bg-[#1c1c1e] text-white border border-[#424242] focus:border-blue-500 outline-none transition disabled:opacity-50 disabled:cursor-not-allowed"
                    />
                  </div>
                </div>
              </div>

              {/* Problem Selection Card */}
              <div className="bg-[#2b2d30] rounded-xl p-6 border border-[#424242]">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-white">Select Problems</h2>
                  <span className="text-sm text-gray-400">
                    {selectedProblems.length} selected
                  </span>
                </div>
                {mode === "free" && (
                  <div className="mb-4 p-3 rounded-lg bg-blue-900/20 border border-blue-700/50 text-blue-300 text-xs">
                    🔓 โหมด Free — นักเรียนจะเข้าถึงโจทย์ทั้งหมดได้ ไม่ต้องเลือกโจทย์เฉพาะเจาะจง
                  </div>
                )}

                {isLoadingProblems ? (
                  <div className="text-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-blue-400" />
                    <p className="text-gray-400 text-sm">Loading problems...</p>
                  </div>
                ) : problems.length === 0 ? (
                  <div className="text-center py-8">
                    <AlertCircle className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                    <p className="text-gray-400 text-sm">No problems found</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {problems.map((problem) => (
                      <label
                        key={problem.id}
                        className="flex items-center gap-3 p-4 rounded-lg bg-[#1c1c1e] hover:bg-[#252529] transition cursor-pointer border border-[#424242] hover:border-blue-500"
                      >
                        <input
                          type="checkbox"
                          checked={selectedProblems.includes(problem.id)}
                          onChange={() => handleToggleProblem(problem.id)}
                          className="w-5 h-5 cursor-pointer accent-blue-500"
                        />
                        <div className="flex-1">
                          <p className="text-white font-medium">{problem.title}</p>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-900/30 text-blue-400 mt-1 inline-block">
                            {problem.concept}
                          </span>
                        </div>
                        <span
                          className={`text-xs px-3 py-1 rounded-full font-medium border ${getDifficultyColor(
                            problem.difficulty
                          )}`}
                        >
                          {formatDifficulty(problem.difficulty)}
                        </span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Right: Summary & Action */}
            <div className="lg:col-span-1">
              <div className="sticky top-6 bg-[#2b2d30] rounded-xl p-6 border border-[#424242]">
                <h3 className="text-lg font-semibold text-white mb-6">Summary</h3>

                <div className="space-y-4 mb-6">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Assignment Name</p>
                    <p className="text-white font-medium break-all">
                      {assignmentName || <span className="text-gray-400">Not set</span>}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">Classroom</p>
                    <p className="text-white font-medium break-all">{classroomId}</p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">Mode</p>
                    <p className="text-white font-medium capitalize">{mode === "guided" ? "Required" : "Optional"}</p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">Problems</p>
                    {mode === "free"
                      ? <p className="text-blue-400 font-medium text-sm">ทั้งหมด (Free mode)</p>
                      : <p className="text-white font-medium text-2xl">{selectedProblems.length}</p>
                    }
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">Due Date & Time</p>
                    <p className="text-white font-medium text-sm">{formatDueDateTime()}</p>
                  </div>
                </div>

                {(mode === "free" || selectedProblems.length > 0) && (
                  <div className="mb-6 p-4 bg-blue-900/20 rounded-lg border border-blue-700">
                    {mode === "free"
                      ? <p className="text-sm text-blue-300">นักเรียนจะเข้าถึง <strong>โจทย์ทั้งหมด</strong> ในห้องเรียนนี้</p>
                      : <p className="text-sm text-blue-300"><strong>{selectedProblems.length}</strong> โจทย์จะถูกมอบหมายให้นักเรียนทุกคน</p>
                    }
                  </div>
                )}

                <button
                  onClick={handleCreateAssignment}
                  disabled={isLoading || !assignmentName.trim() || (mode === "guided" && selectedProblems.length === 0)}
                  className={`w-full py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition ${
                    !assignmentName.trim() || (mode === "guided" && selectedProblems.length === 0)
                      ? "bg-gray-700 text-gray-400 cursor-not-allowed"
                      : "bg-blue-600 hover:bg-blue-700 text-white"
                  }`}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Plus className="w-5 h-5" />
                      Create Assignment
                    </>
                  )}
                </button>

                <Link
                  href={`/dashboard/teacher/classrooms/${classroomId}`}
                  className="w-full mt-3 py-2 rounded-lg font-medium text-gray-400 hover:text-white border border-[#424242] hover:border-gray-400 transition block text-center"
                >
                  Cancel
                </Link>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}