"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import { use, useState, useEffect } from "react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts"
import { api } from "@/lib/api"
import {
  Users,
  TrendingUp,
  AlertCircle,
  Clock,
  CheckCircle2,
  Loader2,
  ChevronRight,
} from "lucide-react"
import Link from "next/link"

interface StudentProfile {
  id: string
  name: string
  email: string
  totalSubmissions: number
  successRate: number
  averageScore: number
  lastSubmitted?: string
  strugglingConcepts: Array<{ concept: string; count: number }>
}

interface StudentSubmission {
  studentId: string
  problemId: string
  score: number
  status: string
  submittedAt: string
  errorType?: string
}

interface ErrorDistribution {
  student: string
  Syntax: number
  IndexError: number
  TypeError: number
  Others: number
}

// Mock student data (replace with API call)
const MOCK_STUDENTS: StudentProfile[] = [
  {
    id: "student_001",
    name: "Charlie Kirk",
    email: "charlie@university.ac.th",
    totalSubmissions: 24,
    successRate: 75,
    averageScore: 78,
    strugglingConcepts: [
      { concept: "Pointers", count: 5 },
      { concept: "Arrays", count: 3 },
    ],
    lastSubmitted: "2 hours ago",
  },
  {
    id: "student_002",
    name: "Jeffrey Epstein",
    email: "jeffrey@university.ac.th",
    totalSubmissions: 18,
    successRate: 67,
    averageScore: 72,
    strugglingConcepts: [
      { concept: "Memory Management", count: 7 },
      { concept: "Recursion", count: 4 },
    ],
    lastSubmitted: "5 hours ago",
  },
  {
    id: "student_003",
    name: "Alice Wong",
    email: "alice@university.ac.th",
    totalSubmissions: 32,
    successRate: 88,
    averageScore: 86,
    strugglingConcepts: [
      { concept: "Templates", count: 2 },
    ],
    lastSubmitted: "1 hour ago",
  },
  {
    id: "student_004",
    name: "Bob Martinez",
    email: "bob@university.ac.th",
    totalSubmissions: 15,
    successRate: 60,
    averageScore: 65,
    strugglingConcepts: [
      { concept: "Strings", count: 6 },
      { concept: "Algorithms", count: 5 },
    ],
    lastSubmitted: "8 hours ago",
  },
]

// Mock error distribution
const ERROR_DISTRIBUTION: ErrorDistribution[] = [
  {
    student: "Charlie Kirk",
    Syntax: 12,
    IndexError: 8,
    TypeError: 6,
    Others: 4,
  },
  {
    student: "Jeffrey Epstein",
    Syntax: 10,
    IndexError: 5,
    TypeError: 8,
    Others: 3,
  },
  {
    student: "Alice Wong",
    Syntax: 5,
    IndexError: 2,
    TypeError: 3,
    Others: 2,
  },
  {
    student: "Bob Martinez",
    Syntax: 8,
    IndexError: 4,
    TypeError: 5,
    Others: 2,
  },
]

const COLORS = {
  Syntax: "#fec53d",
  IndexError: "#f93c65",
  TypeError: "#9d4edd",
  Others: "#696969",
}

export default function TeacherAnalyticsDashboard() {
  const [activeTab, setActiveTab] = useState<"details" | "recent" | "errors">(
    "details"
  )
  const [selectedStudent, setSelectedStudent] = useState<StudentProfile | null>(
    MOCK_STUDENTS[0]
  )
  const [loading, setLoading] = useState(false)

  // Stats
  const totalStudents = MOCK_STUDENTS.length
  const avgSuccessRate = Math.round(
    MOCK_STUDENTS.reduce((sum, s) => sum + s.successRate, 0) / totalStudents
  )
  const avgScore = Math.round(
    MOCK_STUDENTS.reduce((sum, s) => sum + s.averageScore, 0) / totalStudents
  )

  function getStatusColor(successRate: number) {
    if (successRate >= 80) return "#4ad991"
    if (successRate >= 60) return "#fec53d"
    return "#f93c65"
  }

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar role="teacher" userName="Prof. Sarah Chen" userEmail="sarah@university.ac.th" />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Header */}
          <div className="mb-6">
            <h2 className="text-white font-bold text-2xl">Class Analytics</h2>
            <p className="text-[#696969] text-sm mt-1">Monitor student performance and learning patterns</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-[#2b2d30] rounded-2xl p-5 border border-[#3f4046]">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[#696969] text-xs mb-1">Total Students</p>
                  <p className="text-white font-bold text-3xl">{totalStudents}</p>
                </div>
                <Users className="w-8 h-8 text-[#4880ff]" />
              </div>
            </div>
            <div className="bg-[#2b2d30] rounded-2xl p-5 border border-[#3f4046]">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[#696969] text-xs mb-1">Avg Success Rate</p>
                  <p className="text-white font-bold text-3xl">{avgSuccessRate}%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-[#4ad991]" />
              </div>
            </div>
            <div className="bg-[#2b2d30] rounded-2xl p-5 border border-[#3f4046]">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[#696969] text-xs mb-1">Avg Score</p>
                  <p className="text-white font-bold text-3xl">{avgScore}%</p>
                </div>
                <CheckCircle2 className="w-8 h-8 text-[#fec53d]" />
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 bg-[#2b2d30] rounded-xl p-1 w-fit mb-6">
            {(["details", "recent", "errors"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-all capitalize ${
                  activeTab === tab
                    ? "bg-[#4880ff] text-white"
                    : "text-[#696969] hover:text-[#acadb9]"
                }`}
              >
                {tab === "details"
                  ? "Student Details"
                  : tab === "recent"
                    ? "Recent Work"
                    : "Error Distribution"}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="bg-[#2b2d30] rounded-2xl p-6 border border-[#3f4046]">
            {/* Student Details Tab */}
            {activeTab === "details" && (
              <div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-[#3f4046]">
                        <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                          Student
                        </th>
                        <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                          Submissions
                        </th>
                        <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                          Success Rate
                        </th>
                        <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                          Avg Score
                        </th>
                        <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                          Last Submitted
                        </th>
                        <th className="text-left text-[#696969] text-xs font-medium pb-3">
                          Main Issues
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {MOCK_STUDENTS.map((student) => (
                        <tr
                          key={student.id}
                          onClick={() => setSelectedStudent(student)}
                          className="border-b border-[#3f4046]/50 hover:bg-[#363d43]/40 transition-colors cursor-pointer group"
                        >
                          <td className="py-3 pr-4">
                            <div>
                              <p className="text-white text-xs font-semibold group-hover:text-[#4880ff] transition-colors">
                                {student.name}
                              </p>
                              <p className="text-[#696969] text-[10px]">
                                {student.email}
                              </p>
                            </div>
                          </td>
                          <td className="py-3 pr-4">
                            <span className="text-white text-xs font-medium">
                              {student.totalSubmissions}
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            <span
                              className="text-xs font-medium px-2 py-1 rounded-full"
                              style={{
                                color: getStatusColor(student.successRate),
                                background:
                                  getStatusColor(student.successRate) + "22",
                              }}
                            >
                              {student.successRate}%
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            <span className="text-white text-xs font-medium">
                              {student.averageScore}%
                            </span>
                          </td>
                          <td className="py-3 pr-4">
                            <span className="text-[#696969] text-xs">
                              {student.lastSubmitted}
                            </span>
                          </td>
                          <td className="py-3">
                            <div className="flex items-center gap-1">
                              {student.strugglingConcepts.length > 0 ? (
                                <>
                                  <AlertCircle className="w-3.5 h-3.5 text-[#f93c65]" />
                                  <span className="text-[#f93c65] text-xs">
                                    {student.strugglingConcepts[0].concept}
                                  </span>
                                  {student.strugglingConcepts.length > 1 && (
                                    <span className="text-[#696969] text-xs">
                                      +{student.strugglingConcepts.length - 1}
                                    </span>
                                  )}
                                </>
                              ) : (
                                <CheckCircle2 className="w-3.5 h-3.5 text-[#4ad991]" />
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Recent Work Tab */}
            {activeTab === "recent" && (
              <div>
                <h3 className="text-white font-semibold text-sm mb-4">
                  Recent Submissions (Last 48 hours)
                </h3>
                <div className="space-y-2">
                  {MOCK_STUDENTS.map((student) => (
                    <div
                      key={student.id}
                      className="flex items-center justify-between p-3 bg-[#1c1c1e] rounded-lg border border-[#3f4046]"
                    >
                      <div className="flex items-center gap-3 flex-1">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white"
                          style={{
                            background:
                              Math.random() > 0.5 ? "#4880ff" : "#4ad991",
                          }}
                        >
                          {student.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-white text-xs font-semibold">
                            {student.name}
                          </p>
                          <p className="text-[#696969] text-[10px]">
                            {student.totalSubmissions} total submissions
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Clock className="w-3.5 h-3.5 text-[#696969]" />
                        <span className="text-[#696969] text-xs">
                          {student.lastSubmitted}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Error Distribution Tab */}
            {activeTab === "errors" && (
              <div>
                <h3 className="text-white font-semibold text-sm mb-4">
                  Error Distribution by Type
                </h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={ERROR_DISTRIBUTION}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#3f4046" />
                    <XAxis
                      dataKey="student"
                      stroke="#696969"
                      style={{ fontSize: "12px" }}
                    />
                    <YAxis stroke="#696969" style={{ fontSize: "12px" }} />
                    <Tooltip
                      contentStyle={{
                        background: "#2b2d30",
                        border: "1px solid #3f4046",
                        borderRadius: "8px",
                      }}
                      labelStyle={{ color: "#fff" }}
                    />
                    <Legend wrapperStyle={{ color: "#696969" }} />
                    <Bar dataKey="Syntax" stackId="a" fill={COLORS.Syntax} />
                    <Bar
                      dataKey="IndexError"
                      stackId="a"
                      fill={COLORS.IndexError}
                    />
                    <Bar dataKey="TypeError" stackId="a" fill={COLORS.TypeError} />
                    <Bar dataKey="Others" stackId="a" fill={COLORS.Others} />
                  </BarChart>
                </ResponsiveContainer>

                {/* Error insights */}
                <div className="mt-6 space-y-2">
                  <h4 className="text-white font-semibold text-xs">
                    Key Insights
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      {
                        label: "Most Common Error",
                        value: "Syntax Errors (35%)",
                        icon: "📊",
                      },
                      {
                        label: "Highest Error Rate",
                        value: "Charlie Kirk",
                        icon: "⚠️",
                      },
                      {
                        label: "Lowest Error Rate",
                        value: "Alice Wong",
                        icon: "✅",
                      },
                      {
                        label: "Critical Attention",
                        value: "Index Errors (28%)",
                        icon: "🔴",
                      },
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-[#1c1c1e] rounded-lg border border-[#3f4046]"
                      >
                        <p className="text-[#696969] text-[10px] mb-1">
                          {item.label}
                        </p>
                        <p className="text-white text-xs font-semibold">
                          {item.icon} {item.value}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Selected Student Details */}
          {selectedStudent && activeTab === "details" && (
            <div className="mt-6 bg-[#2b2d30] rounded-2xl p-6 border border-[#3f4046]">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-white font-bold text-lg">
                    {selectedStudent.name}
                  </h3>
                  <p className="text-[#696969] text-xs">{selectedStudent.email}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-[#696969] text-xs mb-1">Success Rate</p>
                  <div className="flex items-center gap-2">
                    <p className="text-white font-bold text-xl">
                      {selectedStudent.successRate}%
                    </p>
                    <div className="flex-1 h-2 bg-[#363d43] rounded-full">
                      <div
                        className="h-2 rounded-full transition-all"
                        style={{
                          width: `${selectedStudent.successRate}%`,
                          background: getStatusColor(
                            selectedStudent.successRate
                          ),
                        }}
                      />
                    </div>
                  </div>
                </div>
                <div>
                  <p className="text-[#696969] text-xs mb-1">Average Score</p>
                  <p className="text-white font-bold text-xl">
                    {selectedStudent.averageScore}%
                  </p>
                </div>
              </div>

              {selectedStudent.strugglingConcepts.length > 0 && (
                <div>
                  <p className="text-white font-semibold text-xs mb-2">
                    Struggling Concepts
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {selectedStudent.strugglingConcepts.map((concept) => (
                      <div
                        key={concept.concept}
                        className="px-3 py-1 bg-[#f93c65]/20 border border-[#f93c65]/50 rounded-full"
                      >
                        <p className="text-[#f93c65] text-xs font-medium">
                          {concept.concept}
                        </p>
                        <p className="text-[#f93c65]/70 text-[10px]">
                          {concept.count} errors
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  )
}