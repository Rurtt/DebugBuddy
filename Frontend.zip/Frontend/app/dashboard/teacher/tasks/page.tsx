"use client"

import { Sidebar } from "@/components/debugbuddy/sidebar"
import { Topbar } from "@/components/debugbuddy/topbar"
import { useState, useEffect } from "react"
import { api } from "@/lib/api"
import {
  Plus,
  Search,
  Eye,
  Clock,
  X,
  BookOpen,
  BarChart2,
  Calendar,
  Edit3,
  Trash2,
  Loader2,
  AlertCircle,
  Users,
  CheckCircle2,
  TimerOff,
} from "lucide-react"
import Link from "next/link"

interface Problem {
  id: string
  title: string
  difficulty: string
}

interface Assignment {
  id: string
  name?: string
  classroomId: string
  problemIds: string[]
  problems?: Problem[]
  mode: "guided" | "free"
  dueDate: string
  description?: string
  createdAt?: string
  submittedCount?: number   // how many students have submitted (from backend or default 0)
}

const difficultyColors: Record<string, string> = {
  easy: "#4ad991",
  medium: "#fec53d",
  hard: "#f93c65",
}

const modeLabels: Record<string, string> = {
  guided: "Guided",
  free: "Free",
}

const MAX_STUDENTS = 30

function getAssignmentStatus(assignment: Assignment): {
  label: string
  color: string
  bg: string
  icon: "check" | "timesup" | "pending"
} {
  const now = new Date()
  const due = assignment.dueDate ? new Date(assignment.dueDate) : null
  const submittedCount = assignment.submittedCount ?? 0
  const isTimesUp = due ? now > due : false
  const isCompleted = submittedCount >= MAX_STUDENTS

  if (isCompleted) {
    return { label: "Completed", color: "#4ad991", bg: "#4ad99120", icon: "check" }
  }
  if (isTimesUp) {
    return { label: "Times Up", color: "#f93c65", bg: "#f93c6520", icon: "timesup" }
  }
  return { label: "Pending", color: "#fec53d", bg: "#fec53d20", icon: "pending" }
}

function AssignmentModal({
  assignment,
  onClose,
}: {
  assignment: Assignment
  onClose: () => void
}) {
  const dueDate = new Date(assignment.dueDate)
  const formattedDate = assignment.dueDate
    ? new Date(assignment.dueDate).toLocaleDateString("en-US", { month: "short", day: "numeric" }) +
      " · " + new Date(assignment.dueDate).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
    : "No due date"

  const problems = assignment.problems || []

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.7)" }}
    >
      <div
        className="bg-[#2b2d30] rounded-2xl w-full max-w-xl max-h-[85vh] flex flex-col border border-[#3f4046] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-[#3f4046]">
          <div className="flex flex-col gap-2 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              {/* Status badge */}
              {(() => {
                const s = getAssignmentStatus(assignment)
                return (
                  <span
                    className="text-[10px] px-2 py-0.5 rounded-full font-semibold inline-flex items-center gap-1"
                    style={{ color: s.color, background: s.bg }}
                  >
                    {s.icon === "check" && <CheckCircle2 className="w-3 h-3" />}
                    {s.icon === "timesup" && <TimerOff className="w-3 h-3" />}
                    {s.icon === "pending" && <Clock className="w-3 h-3" />}
                    {s.label}
                  </span>
                )
              })()}
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#363d43] text-[#acadb9]">
                {modeLabels[assignment.mode]}
              </span>
            </div>
            <h2 className="text-white font-bold text-lg">
              {assignment.name || assignment.classroomId}
            </h2>
            <div className="flex items-center gap-4 flex-wrap">
              <span className="flex items-center gap-1.5 text-[#acadb9] text-xs">
                <BookOpen className="w-3.5 h-3.5" />
                {assignment.classroomId}
              </span>
              <span className="flex items-center gap-1.5 text-[#acadb9] text-xs">
                <Calendar className="w-3.5 h-3.5" />
                Due {formattedDate}
              </span>
              <span className="flex items-center gap-1.5 text-[#acadb9] text-xs">
                <Users className="w-3.5 h-3.5" />
                {assignment.submittedCount ?? 0} / {MAX_STUDENTS} submitted
              </span>
              <span className="text-[#acadb9] text-xs">
                {problems.length} problem{problems.length !== 1 ? "s" : ""}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#696969] hover:text-white hover:bg-[#363d43] rounded-lg transition-colors ml-4"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-5">
          {/* Description */}
          {assignment.description && (
            <div>
              <h3 className="text-white font-semibold text-sm mb-2">
                Description
              </h3>
              <p className="text-[#acadb9] text-sm leading-relaxed">
                {assignment.description}
              </p>
            </div>
          )}

          {/* Problems */}
          <div>
            <h3 className="text-white font-semibold text-sm mb-3">
              Assigned Problems ({problems.length})
            </h3>
            <div className="space-y-2">
              {problems.length > 0 ? (
                problems.map((problem) => (
                  <div
                    key={problem.id}
                    className="bg-[#1c1c1e] rounded p-3 border border-[#3f4046]"
                  >
                    <div className="flex items-start justify-between mb-1">
                      <p className="text-white text-xs font-semibold">
                        {problem.title}
                      </p>
                      <span
                        className="text-[10px] px-2 py-0.5 rounded-full font-medium ml-2"
                        style={{
                          color: difficultyColors[problem.difficulty.toLowerCase()],
                          background:
                            difficultyColors[problem.difficulty.toLowerCase()] +
                            "22",
                        }}
                      >
                        {problem.difficulty.charAt(0).toUpperCase() +
                          problem.difficulty.slice(1).toLowerCase()}
                      </span>
                    </div>
                    <p className="text-[#696969] text-[10px]">{problem.id}</p>
                  </div>
                ))
              ) : (
                <p className="text-[#696969] text-xs">No problems assigned</p>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-[#3f4046] p-6 bg-[#1c1c1e] flex gap-3">
          <button className="flex items-center gap-1.5 text-[#acadb9] text-sm px-4 py-2 rounded-lg bg-[#363d43] hover:bg-[#3f4046] transition-colors flex-1">
            <Edit3 className="w-3.5 h-3.5" />
            Edit
          </button>
          <button className="flex items-center gap-1.5 text-[#4880ff] text-sm px-4 py-2 rounded-lg bg-[#4880ff]/10 hover:bg-[#4880ff]/20 border border-[#4880ff]/30 transition-colors flex-1">
            <BarChart2 className="w-3.5 h-3.5" />
            Submissions
          </button>
        </div>
      </div>
    </div>
  )
}

export default function TeacherTasksPage() {
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [search, setSearch] = useState("")
  const [selected, setSelected] = useState<Assignment | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const classroomId = "cpp-core"

  // ============ Load Assignments ============
  useEffect(() => {
    const loadAssignments = async () => {
      try {
        setIsLoading(true)
        setError(null)
        console.log(`📚 Loading assignments for: ${classroomId}`)

        const response = await api.getClassroomAssignments(classroomId)
        console.log("📋 Response:", response)

        if (response?.assignments && Array.isArray(response.assignments)) {
          console.log(`✅ Got ${response.assignments.length} assignments`)
          setAssignments(response.assignments)
        } else {
          console.warn("⚠️ No assignments in response:", response)
          setAssignments([])
        }
      } catch (err) {
        console.error("❌ Error:", err)
        setError(
          `Failed to load: ${err instanceof Error ? err.message : "Unknown error"}`
        )
        setAssignments([])
      } finally {
        setIsLoading(false)
      }
    }

    loadAssignments()
  }, [])

  // ============ Filter Logic ============
  const filtered = assignments.filter((a) => {
    if (!search) return true

    const searchLower = search.toLowerCase()

    // Search in assignment name
    if (a.name?.toLowerCase().includes(searchLower)) return true

    // Search in problems
    const problems = a.problems || []
    const hasProblemMatch = problems.some((p) =>
      p.title.toLowerCase().includes(searchLower) ||
      p.id.toLowerCase().includes(searchLower)
    )

    // Search in classroom
    const hasClassroomMatch = a.classroomId
      .toLowerCase()
      .includes(searchLower)

    return hasProblemMatch || hasClassroomMatch
  })

  // ============ Stats ============
  const statsData = [
    { label: "Total Assignments", value: assignments.length, color: "#acadb9" },
    {
      label: "Completed",
      value: assignments.filter((a) => getAssignmentStatus(a).label === "Completed").length,
      color: "#4ad991",
    },
    {
      label: "Pending",
      value: assignments.filter((a) => getAssignmentStatus(a).label === "Pending").length,
      color: "#fec53d",
    },
    {
      label: "Times Up",
      value: assignments.filter((a) => getAssignmentStatus(a).label === "Times Up").length,
      color: "#f93c65",
    },
  ]

  return (
    <div className="flex min-h-screen bg-[#1c1c1e]">
      <Sidebar
        role="teacher"
        userName="Prof. Sarah Chen"
        userEmail="sarah@university.ac.th"
      />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Topbar showSearch />
        <main className="flex-1 overflow-y-auto p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-white font-bold text-xl">Assignments</h2>
              <p className="text-[#696969] text-sm mt-0.5">
                Manage all assignments for {classroomId}
              </p>
            </div>
            <Link
              href={`/dashboard/teacher/classrooms/${classroomId}/create-assignment`}
              className="flex items-center gap-2 bg-[#4880ff] hover:bg-[#3d72f0] text-white text-xs font-medium px-4 py-2 rounded-lg transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Create Assignment
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-5">
            {statsData.map((s) => (
              <div key={s.label} className="bg-[#2b2d30] rounded-xl p-4">
                <p className="text-[#696969] text-xs mb-1">{s.label}</p>
                <p className="font-bold text-2xl" style={{ color: s.color }}>
                  {s.value}
                </p>
              </div>
            ))}
          </div>

          {/* Search */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#696969]" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search assignments..."
                className="w-full bg-[#2b2d30] border border-[#3f4046] rounded-xl pl-9 pr-4 py-2.5 text-white text-sm placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] transition-colors"
              />
            </div>
          </div>

          {/* Error */}
          {error && (
            <div className="mb-4 p-4 bg-red-900/20 border border-red-700 rounded-xl flex gap-3">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-400 font-semibold text-sm">Error</p>
                <p className="text-red-300 text-xs mt-1">{error}</p>
              </div>
            </div>
          )}

          {/* Loading */}
          {isLoading && (
            <div className="flex items-center justify-center p-12">
              <div className="text-center">
                <Loader2 className="w-8 h-8 text-[#4880ff] animate-spin mx-auto mb-3" />
                <p className="text-[#696969] text-sm">Loading assignments...</p>
              </div>
            </div>
          )}

          {/* Empty */}
          {!isLoading && filtered.length === 0 && (
            <div className="flex items-center justify-center p-12 bg-[#2b2d30] rounded-2xl">
              <div className="text-center">
                <AlertCircle className="w-8 h-8 text-[#696969] mx-auto mb-3" />
                <p className="text-[#696969] text-sm">
                  {assignments.length === 0 ? "No assignments yet" : "No results"}
                </p>
              </div>
            </div>
          )}

          {/* Table */}
          {!isLoading && filtered.length > 0 && (
            <div className="bg-[#2b2d30] rounded-2xl p-5">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#3f4046]">
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Assignment Name
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Classroom
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Submissions
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Mode
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Due Date
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3 pr-4">
                        Status
                      </th>
                      <th className="text-left text-[#696969] text-xs font-medium pb-3">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((a) => {
                      const submittedCount = a.submittedCount ?? 0
                      const status = getAssignmentStatus(a)
                      const due = a.dueDate ? new Date(a.dueDate) : null
                      const formattedDue = due
                        ? due.toLocaleDateString("en-US", { month: "short", day: "numeric" }) +
                          " · " +
                          due.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
                        : "—"
                      return (
                        <tr
                          key={a.id}
                          onClick={() => setSelected(a)}
                          className="border-b border-[#3f4046]/50 hover:bg-[#363d43]/40 transition-colors cursor-pointer group"
                        >
                          {/* Assignment Name */}
                          <td className="py-3 pr-4">
                            <span className="text-white text-xs font-medium group-hover:text-[#4880ff] transition-colors">
                              {a.name || "Unnamed Assignment"}
                            </span>
                          </td>

                          {/* Classroom */}
                          <td className="py-3 pr-4">
                            <span className="text-[#acadb9] text-xs">{a.classroomId}</span>
                          </td>

                          {/* Submissions x/30 */}
                          <td className="py-3 pr-4">
                            <div className="flex items-center gap-1.5">
                              <Users className="w-3 h-3 text-[#696969]" />
                              <span className="text-white text-xs font-semibold">{submittedCount}</span>
                              <span className="text-[#696969] text-xs">/ {MAX_STUDENTS}</span>
                            </div>
                            {/* Mini progress bar */}
                            <div className="mt-1 h-1 w-16 bg-[#363d43] rounded-full overflow-hidden">
                              <div
                                className="h-1 rounded-full transition-all"
                                style={{
                                  width: `${Math.min((submittedCount / MAX_STUDENTS) * 100, 100)}%`,
                                  background: status.color,
                                }}
                              />
                            </div>
                          </td>

                          {/* Mode */}
                          <td className="py-3 pr-4">
                            <span className="text-[#acadb9] text-xs">{modeLabels[a.mode]}</span>
                          </td>

                          {/* Due Date + Time */}
                          <td className="py-3 pr-4">
                            <span className="flex items-center gap-1 text-[#acadb9] text-xs">
                              <Clock className="w-3 h-3" />
                              {formattedDue}
                            </span>
                          </td>

                          {/* Status badge */}
                          <td className="py-3 pr-4">
                            <span
                              className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full"
                              style={{ color: status.color, background: status.bg }}
                            >
                              {status.icon === "check" && <CheckCircle2 className="w-3 h-3" />}
                              {status.icon === "timesup" && <TimerOff className="w-3 h-3" />}
                              {status.icon === "pending" && <Clock className="w-3 h-3" />}
                              {status.label}
                            </span>
                          </td>

                          {/* Actions */}
                          <td className="py-3">
                            <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                              <button
                                onClick={() => setSelected(a)}
                                className="text-[#4880ff] text-xs hover:underline flex items-center gap-1"
                              >
                                <Eye className="w-3 h-3" /> View
                              </button>
                              <button className="text-[#f93c65] hover:text-red-400 transition-colors">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>

      {selected && (
        <div onClick={() => setSelected(null)}>
          <AssignmentModal
            assignment={selected}
            onClose={() => setSelected(null)}
          />
        </div>
      )}
    </div>
  )
}