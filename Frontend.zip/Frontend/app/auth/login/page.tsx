"use client"

import Link from "next/link"
import { useState } from "react"
import { Eye, EyeOff, Bug, GraduationCap, BookOpen } from "lucide-react"
import { useRouter } from "next/navigation"

type Role = "student" | "teacher"

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [role, setRole] = useState<Role>("student")
  const router = useRouter()

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault()
    if (role === "teacher") {
      router.push("/dashboard/teacher")
    } else {
      router.push("/dashboard/student")
    }
  }

  return (
    <div className="min-h-screen bg-[#1c1c1e] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Card */}
        <div className="bg-[#2b2d30] rounded-2xl p-8 shadow-2xl">
          {/* Header */}
          <div className="flex flex-col items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-[#4880ff] flex items-center justify-center">
              <Bug className="w-5 h-5 text-white" />
            </div>
            <div className="text-center">
              <h1 className="text-white font-bold text-xl">Sign in</h1>
              <p className="text-[#696969] text-xs mt-1">Welcome to DebugBuddy</p>
            </div>
          </div>

          {/* Role Selector */}
          <div className="flex gap-2 mb-5 bg-[#1c1c1e] rounded-xl p-1">
            <button
              type="button"
              onClick={() => setRole("student")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all ${
                role === "student"
                  ? "bg-[#4880ff] text-white shadow"
                  : "text-[#696969] hover:text-[#acadb9]"
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              Student
            </button>
            <button
              type="button"
              onClick={() => setRole("teacher")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all ${
                role === "teacher"
                  ? "bg-[#4880ff] text-white shadow"
                  : "text-[#696969] hover:text-[#acadb9]"
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              Teacher
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSignIn} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-[#acadb9] text-xs font-medium">Email or username</label>
              <input
                type="text"
                placeholder={role === "teacher" ? "teacher@university.ac.th" : "student@school.ac.th"}
                className="bg-[#363d43] border border-[#3f4046] rounded-lg px-4 py-2.5 text-white text-sm placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] transition-colors"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-[#acadb9] text-xs font-medium">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  className="w-full bg-[#363d43] border border-[#3f4046] rounded-lg px-4 py-2.5 pr-10 text-white text-sm placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#696969] hover:text-white transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-3.5 h-3.5 accent-[#4880ff]" />
                <span className="text-[#acadb9] text-xs">Remember me</span>
              </label>
              <Link href="/auth/forgot-password" className="text-[#4880ff] text-xs hover:underline">
                Forgot password?
              </Link>
            </div>

            <button
              type="submit"
              className="w-full bg-[#4880ff] hover:bg-[#3d72f0] text-white font-semibold text-sm py-2.5 rounded-lg text-center transition-colors mt-1"
            >
              Sign in as {role === "teacher" ? "Teacher" : "Student"}
            </button>

            <div className="relative flex items-center gap-3">
              <div className="flex-1 h-px bg-[#3f4046]" />
              <span className="text-[#696969] text-xs">OR</span>
              <div className="flex-1 h-px bg-[#3f4046]" />
            </div>

            <button
              type="button"
              className="w-full flex items-center justify-center gap-2 bg-[#363d43] hover:bg-[#3f4046] border border-[#3f4046] text-white font-medium text-sm py-2.5 rounded-lg transition-colors"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Sign in with Google
            </button>
          </form>

          {/* Footer */}
          <p className="text-center text-[#696969] text-xs mt-6">
            {"Don't have an account? "}
            <Link href="/auth/signup" className="text-[#4880ff] hover:underline">
              Sign up
            </Link>
          </p>
        </div>

        {/* Bottom branding */}
        <div className="flex items-center justify-between mt-6 px-2">
          <div className="flex gap-4 text-[#696969] text-xs">
            <Link href="#" className="hover:text-white transition-colors">Privacy</Link>
            <Link href="#" className="hover:text-white transition-colors">Terms</Link>
          </div>
          <span className="text-[#4880ff] text-xs font-semibold">DebugBuddy</span>
        </div>
      </div>
    </div>
  )
}
