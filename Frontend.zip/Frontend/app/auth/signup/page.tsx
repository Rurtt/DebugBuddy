"use client"

import Link from "next/link"
import { useState } from "react"
import { Eye, EyeOff, Bug } from "lucide-react"

export default function SignUpPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)

  return (
    <div className="min-h-screen bg-[#1c1c1e] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Card */}
        <div className="bg-[#2b2d30] rounded-2xl p-8 shadow-2xl">
          {/* Header */}
          <div className="flex flex-col items-center gap-3 mb-7">
            <div className="w-10 h-10 rounded-xl bg-[#4880ff] flex items-center justify-center">
              <Bug className="w-5 h-5 text-white" />
            </div>
            <div className="text-center">
              <h1 className="text-white font-bold text-xl">Sign up</h1>
              <p className="text-[#696969] text-xs mt-1">Welcome to DebugBuddy</p>
            </div>
          </div>

          {/* Form */}
          <form className="flex flex-col gap-3.5">
            <div className="flex flex-col gap-1.5">
              <label className="text-[#acadb9] text-xs font-medium">Full Name</label>
              <input
                type="text"
                placeholder="Enter your full name"
                className="bg-[#363d43] border border-[#3f4046] rounded-lg px-4 py-2.5 text-white text-sm placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] transition-colors"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-[#acadb9] text-xs font-medium">Email</label>
              <input
                type="email"
                placeholder="Enter your email"
                className="bg-[#363d43] border border-[#3f4046] rounded-lg px-4 py-2.5 text-white text-sm placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] transition-colors"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-[#acadb9] text-xs font-medium">Role</label>
              <select className="bg-[#363d43] border border-[#3f4046] rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-[#4880ff] transition-colors">
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
              </select>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-[#acadb9] text-xs font-medium">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Create a password"
                  className="w-full bg-[#363d43] border border-[#3f4046] rounded-lg px-4 py-2.5 pr-10 text-white text-sm placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#696969] hover:text-white transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-[#acadb9] text-xs font-medium">Confirm Password</label>
              <div className="relative">
                <input
                  type={showConfirm ? "text" : "password"}
                  placeholder="Confirm your password"
                  className="w-full bg-[#363d43] border border-[#3f4046] rounded-lg px-4 py-2.5 pr-10 text-white text-sm placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#696969] hover:text-white transition-colors"
                >
                  {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <Link
              href="/dashboard/student"
              className="w-full bg-[#acbed5] hover:bg-[#bbc6da] text-[#1c1c1e] font-semibold text-sm py-2.5 rounded-lg text-center transition-colors mt-1"
            >
              Sign up
            </Link>

            <div className="relative flex items-center gap-3">
              <div className="flex-1 h-px bg-[#3f4046]" />
              <span className="text-[#696969] text-xs">OR</span>
              <div className="flex-1 h-px bg-[#3f4046]" />
            </div>

            <button
              type="button"
              className="w-full flex items-center justify-center gap-2 bg-[#e3ecff] hover:bg-[#d0deff] text-[#1c1c1e] font-medium text-sm py-2.5 rounded-lg transition-colors"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Sign up with Google
            </button>
          </form>

          {/* Footer */}
          <p className="text-center text-[#696969] text-xs mt-5">
            Already have an account?{" "}
            <Link href="/auth/login" className="text-[#4880ff] hover:underline">
              Sign in
            </Link>
          </p>
        </div>

        <div className="flex items-center justify-between mt-6 px-2">
          <div className="flex gap-4 text-[#696969] text-xs">
            <Link href="#" className="hover:text-white transition-colors">Privacy</Link>
            <Link href="#" className="hover:text-white transition-colors">Terms</Link>
          </div>
          <span className="text-[#4880ff] text-xs font-semibold">DebugBuddy</span>
        </div>
      </div>
    </div>
  )
}
