/**
 * API Client Library
 * Handles all communication with DebugBuddy backend
 * Type-safe with proper error handling
 */

import type {
  SubmitCodeRequest,
  SubmitCodeResponse,
  StudentUIResponse,
} from "@shared/types";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3001";

export interface ApiError {
  code: string;
  message: string;
  statusCode: number;
}

class APIClient {
  private baseUrl: string;

  constructor(baseUrl: string = API_BASE) {
    this.baseUrl = baseUrl;
  }

  private async request<T>(
    path: string,
    options: RequestInit = {}
  ): Promise<T> {
    try {
      const url = `${this.baseUrl}${path}`;
      const response = await fetch(url, {
        headers: {
          "Content-Type": "application/json",
          ...options.headers,
        },
        ...options,
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw {
          code: error.code || "UNKNOWN_ERROR",
          message: error.message || response.statusText,
          statusCode: response.status,
        } as ApiError;
      }

      return await response.json();
    } catch (error) {
      if (error instanceof Error) {
        throw {
          code: "NETWORK_ERROR",
          message: error.message,
          statusCode: 0,
        } as ApiError;
      }
      throw error;
    }
  }

  // ========== CODE SUBMISSION ==========

  /**
   * Submit C++ code for evaluation
   * @param studentId - Student ID
   * @param problemId - Problem ID
   * @param classroomId - Classroom ID
   * @param code - C++ code to submit
   */
  async submitCode(
    studentId: string,
    problemId: string,
    classroomId: string,
    code: string
  ): Promise<SubmitCodeResponse> {
    const request: SubmitCodeRequest = {
      studentId,
      problemId,
      classroomId,
      code,
    };

    return this.request<SubmitCodeResponse>("/api/submit", {
      method: "POST",
      body: JSON.stringify(request),
    });
  }

  // ========== PROBLEMS ==========

  /**
   * Get all problems for a classroom
   */
  async getProblems(classroomId: string) {
    return this.request(`/api/problems?classroomId=${classroomId}`);
  }

  /**
   * Get a specific problem
   */
  async getProblem(problemId: string) {
    return this.request(`/api/problems/${problemId}`);
  }

  // ========== STUDENT DASHBOARD ==========

  /**
   * Get student progress for a specific problem
   */
  async getStudentProgress(
    studentId: string,
    problemId: string,
    classroomId: string
  ) {
    return this.request(
      `/api/students/${studentId}/progress?problemId=${problemId}&classroomId=${classroomId}`
    );
  }

  /**
   * Get all submissions for a student
   */
  async getStudentSubmissions(studentId: string, classroomId: string) {
    return this.request(
      `/api/students/${studentId}/submissions?classroomId=${classroomId}`
    );
  }

  /**
   * Get available problems for a student
   */
  async getAvailableProblems(studentId: string, classroomId: string) {
    return this.request(
      `/api/students/${studentId}/available-problems?classroomId=${classroomId}`
    );
  }

  // ========== TEACHER DASHBOARD ==========

  /**
   * Get classroom dashboard data for teacher
   */
  async getClassroomDashboard(classroomId: string) {
    return this.request(`/api/classroom/${classroomId}/dashboard`);
  }

  /**
   * Get all assignments for a classroom
   */
  async getClassroomAssignments(classroomId: string) {
    return this.request(`/api/classroom/${classroomId}/assignments`);
  }

  /**
   * Create a new assignment
   */
  async createAssignment(
    classroomId: string,
    problemIds: string[],
    mode: "guided" | "free",
    dueDate?: Date,
    description?: string,
    name?: string
  ) {
    return this.request(`/api/classroom/${classroomId}/assignments`, {
      method: "POST",
      body: JSON.stringify({
        name,
        problemIds,
        mode,
        dueDate,
        description,
      }),
    });
  }

  // ========== STUDENT DASHBOARD ==========

  /**
   * Get aggregated student dashboard data
   */
  async getStudentDashboard(studentId: string, classroomId: string) {
    return this.request(`/api/students/${studentId}/dashboard?classroomId=${classroomId}`)
  }

  // ========== HEALTH ==========

  /**
   * Check API health
   */
  async health() {
    return this.request("/health");
  }
}

export const api = new APIClient();