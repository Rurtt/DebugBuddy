"use client"

import { Bell, Search } from "lucide-react"
import Image from "next/image"

interface TopbarProps {
  title?: string
  showSearch?: boolean
}

export function Topbar({ title, showSearch = true }: TopbarProps) {
  return (
    <header className="flex items-center justify-between px-6 py-3 bg-[#1c1c1e] border-b border-[#3f4046] shrink-0">
      <div className="flex items-center gap-3">
        {showSearch && (
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#696969]" />
            <input
              type="text"
              placeholder="Search..."
              className="bg-[#2b2d30] border border-[#3f4046] rounded-lg pl-9 pr-4 py-1.5 text-xs text-white placeholder:text-[#696969] focus:outline-none focus:border-[#4880ff] w-48"
            />
          </div>
        )}
        {title && <h1 className="text-white font-semibold text-sm">{title}</h1>}
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 bg-[#2b2d30] border border-[#3f4046] rounded-full px-3 py-1">
          <div className="w-1.5 h-1.5 rounded-full bg-[#4ad991]" />
          <span className="text-[#acadb9] text-xs">EN</span>
        </div>
        <button className="relative p-1.5 rounded-lg hover:bg-[#2b2d30] transition-colors">
          <Bell className="w-4 h-4 text-[#acadb9]" />
          <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-[#4880ff] rounded-full" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-[#4880ff] flex items-center justify-center text-white text-xs font-bold">
            J
          </div>
          <span className="text-[#acadb9] text-xs">John</span>
        </div>
        <span className="text-[#4880ff] text-xs font-semibold bg-[#2b2d30] px-2 py-1 rounded border border-[#4880ff]/30">
          DebugBuddy
        </span>
      </div>
    </header>
  )
}
