"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  BookOpen,
  FileText,
  Users,
  Code2,
  LogOut,
  Settings,
  Bug,
} from "lucide-react"
import { cn } from "@/lib/utils"

const studentNav = [
  { href: "/dashboard/student", label: "Dashboard", icon: LayoutDashboard },
  { href: "/dashboard/student/classrooms", label: "Classrooms", icon: BookOpen },
  { href: "/dashboard/student/tasks", label: "Tasks", icon: FileText },
  { href: "/dashboard/student/ide", label: "IDE", icon: Code2 },
]

const teacherNav = [
  { href: "/dashboard/teacher", label: "Dashboard", icon: LayoutDashboard },
  { href: "/dashboard/teacher/classrooms", label: "Classrooms", icon: BookOpen },
  { href: "/dashboard/teacher/tasks", label: "Tasks", icon: FileText },
  { href: "/dashboard/teacher/students", label: "Students", icon: Users },
]

interface SidebarProps {
  role?: "student" | "teacher"
  userName?: string
  userEmail?: string
}

export function Sidebar({ role = "student", userName = "John Doe", userEmail = "john@example.com" }: SidebarProps) {
  const pathname = usePathname()
  const navItems = role === "teacher" ? teacherNav : studentNav

  return (
    <aside className="flex flex-col w-[200px] min-h-screen bg-[#292b30] border-r border-[#3f4046] shrink-0">
      {/* Logo */}
      <div className="flex items-center gap-2 px-4 py-5 border-b border-[#3f4046]">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#4880ff]">
          <Bug className="w-4 h-4 text-white" />
        </div>
        <span className="font-semibold text-white text-sm">DebugBuddy</span>
      </div>

      {/* User info */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-[#3f4046]">
        <div className="w-8 h-8 rounded-full bg-[#4880ff] flex items-center justify-center text-white text-xs font-bold shrink-0">
          {userName.charAt(0).toUpperCase()}
        </div>
        <div className="overflow-hidden">
          <p className="text-white text-xs font-medium truncate">{userName}</p>
          <p className="text-[#696969] text-[10px] truncate">{userEmail}</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex flex-col gap-1 px-3 py-4 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                isActive
                  ? "bg-[#4880ff] text-white"
                  : "text-[#acadb9] hover:bg-[#363d43] hover:text-white"
              )}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {item.label}
            </Link>
          )
        })}
      </nav>

      {/* Bottom actions */}
      <div className="px-3 py-4 border-t border-[#3f4046] flex flex-col gap-1">
        <Link
          href="/settings"
          className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-[#acadb9] hover:bg-[#363d43] hover:text-white transition-colors"
        >
          <Settings className="w-4 h-4" />
          Settings
        </Link>
        <Link
          href="/auth/login"
          className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-[#acadb9] hover:bg-[#363d43] hover:text-white transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </Link>
      </div>
    </aside>
  )
}
